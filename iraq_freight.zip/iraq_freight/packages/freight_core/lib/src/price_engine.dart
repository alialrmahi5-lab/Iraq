import 'package:equatable/equatable.dart';

import 'iraq_data.dart';
import 'models.dart';

/// نتيجة احتساب السعر (كل المبالغ بالدينار العراقي)
class PriceQuote extends Equatable {
  final double distanceKm;
  final double baseFare; // أجرة الشحن الأساسية
  final double distanceFare; // أجرة المسافة
  final double refrigerationFee; // رسوم البراد / السيارة المغلقة
  final double insuranceFee; // رسوم تأمين البضاعة
  final double total; // الإجمالي على التاجر
  final double driverNet; // صافي ربح السائق بعد عمولة المنصة

  const PriceQuote({
    required this.distanceKm,
    required this.baseFare,
    required this.distanceFare,
    required this.refrigerationFee,
    required this.insuranceFee,
    required this.total,
    required this.driverNet,
  });

  @override
  List<Object?> get props =>
      [distanceKm, baseFare, distanceFare, refrigerationFee, insuranceFee, total, driverNet];
}

/// محرك التسعير الديناميكي.
///
///   أجرة المسافة = المسافة (كم) × سعر الكيلومتر × معامل المركبة
///   الشحن        = الأجرة الأساسية للمركبة + أجرة المسافة
///   البراد       = 20% من الشحن (عند الطلب)
///   التأمين      = 1% من قيمة البضاعة المصرّح بها (أو من الشحن إن لم تُذكر)
///
/// ⚠️ الأرقام أدناه قيم ابتدائية للتجربة، عدّلها بحسب أسعار السوق الفعلية.
class PriceEngine {
  static const ratePerKm = 400.0; // دينار لكل كم لسيارة البيك آب

  static const baseFares = <VehicleType, double>{
    VehicleType.pickup: 20000,
    VehicleType.jumbo: 40000,
    VehicleType.trailer: 80000,
  };

  static const vehicleMultiplier = <VehicleType, double>{
    VehicleType.pickup: 1.0,
    VehicleType.jumbo: 2.0,
    VehicleType.trailer: 3.5,
  };

  static const refrigerationRate = 0.20;
  static const insuranceRate = 0.01;
  static const platformCommission = 0.12;

  static double _round(double v) => (v / 1000).round() * 1000.0;

  static PriceQuote quote({
    required String fromGov,
    required String toGov,
    required VehicleType vehicle,
    bool needsRefrigeration = false,
    bool insured = false,
    double declaredValue = 0,
  }) {
    final km = IraqData.distanceKm(fromGov, toGov);
    final base = baseFares[vehicle]!;
    final distanceFare = _round(km * ratePerKm * vehicleMultiplier[vehicle]!);
    final freight = base + distanceFare;
    final fridge = needsRefrigeration ? _round(freight * refrigerationRate) : 0.0;
    final insurance =
        insured ? _round((declaredValue > 0 ? declaredValue : freight) * insuranceRate) : 0.0;
    final total = freight + fridge + insurance;
    final driverNet = _round((freight + fridge) * (1 - platformCommission));
    return PriceQuote(
      distanceKm: km,
      baseFare: base,
      distanceFare: distanceFare,
      refrigerationFee: fridge,
      insuranceFee: insurance,
      total: total,
      driverNet: driverNet,
    );
  }
}
