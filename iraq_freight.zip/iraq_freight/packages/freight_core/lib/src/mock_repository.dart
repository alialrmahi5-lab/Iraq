import 'dart:async';
import 'dart:io';
import 'dart:math' as math;

import 'config.dart';
import 'iraq_data.dart';
import 'models.dart';
import 'price_engine.dart';
import 'repository.dart';

/// تنفيذ تجريبي داخل الذاكرة لتجربة التطبيقين بدون أي خادم.
///
///  - تطبيق التاجر: بعد حجز شحنة يقبلها «سائق وهمي» بعد 8 ثوانٍ ثم يتحرك على الخريطة.
///  - تطبيق السائق: يصل طلب جديد كل 40 ثانية لتجربة التنبيه الصوتي.
///
/// ملاحظة: التطبيقان عمليتان منفصلتان، لذلك لا يتشاركان البيانات في الوضع التجريبي.
class MockFreightRepository implements FreightRepository {
  final UserRole role;
  MockFreightRepository(this.role);

  /// الطلبات الابتدائية تُنشأ عند أول مشاهدة للجدار (بعد معرفة مركبة السائق)
  bool _seeded = false;

  final _changes = StreamController<void>.broadcast();
  final _shipments = <String, Shipment>{};
  final _profiles = <String, AppUser>{};
  final _wallets = <String, double>{};
  final _rand = math.Random();
  AppUser? _user;
  Timer? _jobTimer;
  int _seq = 0;

  void _put(Shipment s) {
    _shipments[s.id] = s;
    _changes.add(null);
  }

  Future<void> _delay([int ms = 500]) => Future.delayed(Duration(milliseconds: ms));

  // ───────── المصادقة ─────────
  @override
  Future<void> sendOtp(String phone) => _delay();

  @override
  Future<AppUser> verifyOtp(String phone, String code) async {
    await _delay();
    if (code != AppConfig.mockOtp) {
      throw const FreightException('رمز التحقق غير صحيح (التجريبي: 123456)');
    }
    final id = 'mock-${role.name}-$phone';
    _user = _profiles[id] ?? AppUser(id: id, phone: phone, role: role);
    _profiles[id] = _user!;
    return _user!;
  }

  @override
  Future<AppUser?> currentUser() async => _user;

  @override
  Future<AppUser> saveProfile(AppUser user) async {
    await _delay(300);
    _user = user;
    _profiles[user.id] = user;
    return user;
  }

  @override
  Future<void> signOut() async => _user = null;

  // ───────── التاجر ─────────
  @override
  Future<Shipment> createShipment(Shipment d,
      {required String merchantName, required String merchantPhone}) async {
    await _delay(700);
    final s = Shipment(
      id: 'S${1000 + (++_seq)}',
      merchantId: d.merchantId,
      cargo: d.cargo,
      weight: d.weight,
      vehicle: d.vehicle,
      fromGov: d.fromGov,
      toGov: d.toGov,
      fromLat: d.fromLat,
      fromLng: d.fromLng,
      toLat: d.toLat,
      toLng: d.toLng,
      notes: d.notes,
      needsRefrigeration: d.needsRefrigeration,
      insured: d.insured,
      declaredValue: d.declaredValue,
      distanceKm: d.distanceKm,
      baseFare: d.baseFare,
      distanceFare: d.distanceFare,
      refrigerationFee: d.refrigerationFee,
      insuranceFee: d.insuranceFee,
      total: d.total,
      driverNet: d.driverNet,
      paymentMethod: d.paymentMethod,
      createdAt: DateTime.now(),
      merchantName: merchantName,
      merchantPhone: merchantPhone,
    );
    _put(s);
    if (role == UserRole.merchant) _simulateDriver(s.id);
    return s;
  }

  /// سائق وهمي: يقبل بعد 8 ثوانٍ ثم يتحرك من التحميل إلى التسليم
  void _simulateDriver(String id) {
    Timer(const Duration(seconds: 8), () {
      final s = _shipments[id];
      if (s == null || s.status != ShipmentStatus.open) return;
      _put(s.copyWith(
        status: ShipmentStatus.accepted,
        driverId: 'mock-driver',
        driverName: 'أبو حيدر',
        driverPhone: '07701234567',
        driverLat: s.fromLat,
        driverLng: s.fromLng,
      ));
      var step = 0;
      Timer.periodic(const Duration(seconds: 3), (t) {
        final cur = _shipments[id];
        if (cur == null || !cur.status.isActive) {
          t.cancel();
          return;
        }
        step++;
        final p = (step / 30).clamp(0.0, 1.0);
        var st = cur.status;
        if (step == 3) st = ShipmentStatus.atPickup;
        if (step == 6) st = ShipmentStatus.inTransit;
        if (step == 28) st = ShipmentStatus.atDropoff;
        if (step >= 30) {
          st = ShipmentStatus.delivered;
          t.cancel();
        }
        _put(cur.copyWith(
          status: st,
          driverLat: cur.fromLat + (cur.toLat - cur.fromLat) * p,
          driverLng: cur.fromLng + (cur.toLng - cur.fromLng) * p,
        ));
      });
    });
  }

  List<Shipment> _sorted(Iterable<Shipment> it) =>
      it.toList()..sort((a, b) => b.createdAt.compareTo(a.createdAt));

  @override
  Stream<List<Shipment>> watchMerchantShipments(String merchantId) async* {
    List<Shipment> snap() => _sorted(_shipments.values.where((s) => s.merchantId == merchantId));
    yield snap();
    yield* _changes.stream.map((_) => snap());
  }

  @override
  Stream<Shipment> watchShipment(String id) async* {
    if (_shipments[id] != null) yield _shipments[id]!;
    yield* _changes.stream.where((_) => _shipments[id] != null).map((_) => _shipments[id]!);
  }

  @override
  Future<void> cancelShipment(String id) async {
    final s = _shipments[id];
    if (s != null && s.status.isActive) _put(s.copyWith(status: ShipmentStatus.cancelled));
  }

  @override
  Future<double> walletBalance(String userId) async => _wallets[userId] ?? 0;

  @override
  Future<double> topUpWallet(String userId, double amount) async {
    await _delay(400);
    return _wallets[userId] = (_wallets[userId] ?? 0) + amount;
  }

  @override
  Future<void> payWithWallet(String userId, double amount) async {
    final bal = _wallets[userId] ?? 0;
    if (bal < amount) throw const FreightException('رصيد المحفظة غير كافٍ');
    _wallets[userId] = bal - amount;
  }

  // ───────── السائق ─────────
  void _seedOpenJobs() {
    for (var i = 0; i < 4; i++) {
      _addRandomJob(match: true);
    }
  }

  static const _routes = [
    ['baghdad', 'basra'],
    ['baghdad', 'erbil'],
    ['najaf', 'baghdad'],
    ['basra', 'baghdad'],
    ['karbala', 'nineveh'],
    ['baghdad', 'najaf'],
    ['erbil', 'baghdad'],
    ['basra', 'najaf'],
  ];

  void _addRandomJob({bool match = false}) {
    final r = _routes[_rand.nextInt(_routes.length)];
    // أغلب الطلبات التجريبية تطابق مركبة السائق ليظهر التنبيه، وربعها لا يطابق
    final randomVehicle = VehicleType.values[_rand.nextInt(VehicleType.values.length)];
    final vehicle = (match || _rand.nextInt(4) != 0) ? (_user?.vehicle ?? randomVehicle) : randomVehicle;
    // الوزن يتبع المركبة حتى تكون البطاقة منطقية (بيك آب ← أقل من 2 طن ...)
    final weight = WeightClass.values.firstWhere((w) => w.recommendedVehicle == vehicle);
    final q = PriceEngine.quote(fromGov: r[0], toGov: r[1], vehicle: vehicle);
    final a = IraqData.byId(r[0]), b = IraqData.byId(r[1]);
    final id = 'S${2000 + (++_seq)}';
    _put(Shipment(
      id: id,
      merchantId: 'mock-merchant',
      cargo: CargoType.values[_rand.nextInt(CargoType.values.length)],
      weight: weight,
      vehicle: vehicle,
      fromGov: r[0],
      toGov: r[1],
      fromLat: a.lat,
      fromLng: a.lng,
      toLat: b.lat,
      toLng: b.lng,
      distanceKm: q.distanceKm,
      baseFare: q.baseFare,
      distanceFare: q.distanceFare,
      total: q.total,
      driverNet: q.driverNet,
      paymentMethod: PaymentMethod.cashOnDelivery,
      createdAt: DateTime.now(),
      merchantName: 'شركة الرافدين للتجارة',
      merchantPhone: '07801234567',
    ));
  }

  @override
  Stream<List<Shipment>> watchOpenShipments() async* {
    if (!_seeded) {
      _seeded = true;
      _seedOpenJobs();
    }
    _jobTimer ??= Timer.periodic(const Duration(seconds: 40), (_) => _addRandomJob());
    List<Shipment> snap() =>
        _sorted(_shipments.values.where((s) => s.status == ShipmentStatus.open));
    yield snap();
    yield* _changes.stream.map((_) => snap());
  }

  @override
  Stream<List<Shipment>> watchDriverShipments(String driverId) async* {
    List<Shipment> snap() => _sorted(_shipments.values.where((s) => s.driverId == driverId));
    yield snap();
    yield* _changes.stream.map((_) => snap());
  }

  @override
  Future<Shipment> acceptShipment(String id, AppUser driver) async {
    await _delay(400);
    final s = _shipments[id];
    if (s == null || s.status != ShipmentStatus.open) {
      throw const FreightException('عذراً، هذا الطلب أخذه سائق آخر', code: FreightException.taken);
    }
    final updated = s.copyWith(
      status: ShipmentStatus.accepted,
      driverId: driver.id,
      driverName: driver.fullName,
      driverPhone: driver.phone,
    );
    _put(updated);
    return updated;
  }

  @override
  Future<void> updateStatus(String id, ShipmentStatus status) async {
    final s = _shipments[id];
    if (s != null) _put(s.copyWith(status: status));
  }

  @override
  Future<void> pushDriverLocation(String id, double lat, double lng) async {
    final s = _shipments[id];
    if (s != null) _put(s.copyWith(driverLat: lat, driverLng: lng));
  }

  @override
  Future<String> uploadFile(String bucket, String path, File file) async {
    await _delay(600);
    return 'mock/$bucket/$path';
  }

  final _docsSubmitted = <String>{};

  @override
  Future<bool> hasSubmittedDocs(String userId) async => _docsSubmitted.contains(userId);

  @override
  Future<void> submitDriverDocs(String userId, Map<String, String> paths) async {
    await _delay(600);
    _docsSubmitted.add(userId);
    // في الوضع التجريبي يُعتمد السائق مباشرة
    final u = _profiles[userId];
    if (u != null) {
      _user = _profiles[userId] = u.copyWith(verification: VerificationStatus.approved);
    }
  }

  @override
  Future<void> completeWithProof(String id, String proofPath) async {
    final s = _shipments[id];
    if (s != null) _put(s.copyWith(status: ShipmentStatus.delivered, proofPath: proofPath));
  }
}
