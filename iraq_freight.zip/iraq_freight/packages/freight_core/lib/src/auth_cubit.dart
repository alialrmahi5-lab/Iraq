import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'models.dart';
import 'repository.dart';

enum AuthStatus { unknown, signedOut, otpSent, needsProfile, ready }

class AuthState extends Equatable {
  final AuthStatus status;
  final String phone;
  final AppUser? user;
  final bool busy;
  final String? error;

  const AuthState({
    this.status = AuthStatus.unknown,
    this.phone = '',
    this.user,
    this.busy = false,
    this.error,
  });

  AuthState copyWith({AuthStatus? status, String? phone, AppUser? user, bool? busy, String? error}) =>
      AuthState(
        status: status ?? this.status,
        phone: phone ?? this.phone,
        user: user ?? this.user,
        busy: busy ?? false,
        error: error, // يُمسح تلقائياً ما لم يُمرَّر
      );

  @override
  List<Object?> get props => [status, phone, user, busy, error];
}

/// مصادقة مشتركة بين التطبيقين: هاتف ← OTP ← إكمال الملف الشخصي
class AuthCubit extends Cubit<AuthState> {
  AuthCubit(this._repo) : super(const AuthState());
  final FreightRepository _repo;

  AuthStatus _statusFor(AppUser u) => u.profileComplete ? AuthStatus.ready : AuthStatus.needsProfile;

  /// عند فتح التطبيق: استعادة الجلسة إن وُجدت
  Future<void> start() async {
    final u = await _repo.currentUser();
    emit(u == null
        ? const AuthState(status: AuthStatus.signedOut)
        : AuthState(status: _statusFor(u), user: u, phone: u.phone));
  }

  Future<void> sendOtp(String phone) async {
    if (!RegExp(r'^(\+?964|0)?7\d{9}$').hasMatch(phone.replaceAll(' ', ''))) {
      emit(state.copyWith(error: 'أدخل رقم هاتف عراقي صحيح مثل 07701234567'));
      return;
    }
    emit(state.copyWith(busy: true, phone: phone));
    try {
      await _repo.sendOtp(phone);
      emit(state.copyWith(status: AuthStatus.otpSent, phone: phone));
    } on FreightException catch (e) {
      emit(state.copyWith(error: e.message));
    }
  }

  Future<void> verifyOtp(String code) async {
    emit(state.copyWith(busy: true));
    try {
      final u = await _repo.verifyOtp(state.phone, code.trim());
      emit(AuthState(status: _statusFor(u), user: u, phone: state.phone));
    } on FreightException catch (e) {
      emit(state.copyWith(error: e.message));
    }
  }

  void backToPhone() => emit(const AuthState(status: AuthStatus.signedOut));

  Future<void> completeProfile(AppUser u) async {
    emit(state.copyWith(busy: true));
    try {
      final saved = await _repo.saveProfile(u);
      emit(AuthState(status: _statusFor(saved), user: saved, phone: saved.phone));
    } on FreightException catch (e) {
      emit(state.copyWith(error: e.message));
    }
  }

  /// يعيد تحميل بيانات المستخدم (مثلاً لمعرفة هل اعتُمد السائق)
  Future<void> refresh() async {
    final u = await _repo.currentUser();
    if (u != null) emit(AuthState(status: _statusFor(u), user: u, phone: u.phone));
  }

  /// يحدّث المستخدم محلياً بعد عمليات مثل رفع الوثائق
  Future<void> signOut() async {
    await _repo.signOut();
    emit(const AuthState(status: AuthStatus.signedOut));
  }
}
