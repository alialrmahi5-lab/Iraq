/// إعدادات النظام. تُمرَّر القيم وقت البناء عبر --dart-define:
///   flutter run --dart-define=SUPABASE_URL=... --dart-define=SUPABASE_ANON_KEY=...
class AppConfig {
  static const supabaseUrl = String.fromEnvironment('SUPABASE_URL');
  static const supabaseAnonKey = String.fromEnvironment('SUPABASE_ANON_KEY');

  /// عند غياب مفاتيح Supabase يعمل التطبيق بالوضع التجريبي
  /// (بيانات داخل الذاكرة + محاكاة سائق/طلبات) لتجربة الواجهات بدون باكيند.
  static bool get useMock => supabaseUrl.isEmpty || supabaseAnonKey.isEmpty;

  /// رمز التحقق في الوضع التجريبي
  static const mockOtp = '123456';
}
