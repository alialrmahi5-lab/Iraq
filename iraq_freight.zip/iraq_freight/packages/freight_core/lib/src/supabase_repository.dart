import 'dart:async';
import 'dart:io';

import 'package:supabase_flutter/supabase_flutter.dart';

import 'models.dart';
import 'repository.dart';
import 'utils.dart';

/// تنفيذ الإنتاج فوق Supabase (مخطط الجداول في supabase/schema.sql)
class SupabaseFreightRepository implements FreightRepository {
  final UserRole role;
  SupabaseFreightRepository(this.role);

  SupabaseClient get _db => Supabase.instance.client;

  /// يحوّل أخطاء الخادم إلى رسائل عربية مفهومة
  Never _fail(Object e) {
    final msg = e.toString();
    if (msg.contains('already_taken')) {
      throw const FreightException('عذراً، هذا الطلب أخذه سائق آخر', code: FreightException.taken);
    }
    if (msg.contains('driver_not_approved')) {
      throw const FreightException('حسابك قيد المراجعة ولا يمكنك قبول الطلبات بعد');
    }
    if (msg.contains('insufficient_funds')) {
      throw const FreightException('رصيد المحفظة غير كافٍ');
    }
    if (e is AuthException) throw FreightException(e.message);
    throw FreightException('حدث خطأ في الاتصال، تأكد من الإنترنت وحاول مجدداً');
  }

  // ───────── المصادقة ─────────
  @override
  Future<void> sendOtp(String phone) async {
    try {
      await _db.auth.signInWithOtp(phone: toE164(phone));
    } catch (e) {
      _fail(e);
    }
  }

  @override
  Future<AppUser> verifyOtp(String phone, String code) async {
    try {
      final res = await _db.auth.verifyOTP(phone: toE164(phone), token: code, type: OtpType.sms);
      final uid = res.user!.id;
      final row = await _db.from('profiles').select().eq('id', uid).maybeSingle();
      if (row != null) {
        final u = AppUser.fromJson(row);
        if (u.role != role) {
          await _db.auth.signOut();
          throw FreightException(u.role == UserRole.driver
              ? 'هذا الرقم مسجّل كسائق، استخدم تطبيق السائق'
              : 'هذا الرقم مسجّل كتاجر، استخدم تطبيق التاجر');
        }
        return u;
      }
      return AppUser(id: uid, phone: toE164(phone), role: role);
    } on FreightException {
      rethrow;
    } catch (e) {
      _fail(e);
    }
  }

  @override
  Future<AppUser?> currentUser() async {
    final u = _db.auth.currentUser;
    if (u == null) return null;
    try {
      final row = await _db.from('profiles').select().eq('id', u.id).maybeSingle();
      if (row != null) return AppUser.fromJson(row);
      return AppUser(id: u.id, phone: u.phone ?? '', role: role);
    } catch (_) {
      return null;
    }
  }

  @override
  Future<AppUser> saveProfile(AppUser user) async {
    try {
      final row = await _db.from('profiles').upsert(user.toJson()).select().single();
      return AppUser.fromJson(row);
    } catch (e) {
      _fail(e);
    }
  }

  @override
  Future<void> signOut() => _db.auth.signOut();

  // ───────── بيانات الاتصال (جدول منفصل لا يراه إلا الطرفان) ─────────
  Future<List<Shipment>> _withContacts(List<Shipment> list) async {
    if (list.isEmpty) return list;
    final ids = list.where((s) => s.status != ShipmentStatus.open || role == UserRole.merchant).map((s) => s.id).toList();
    if (ids.isEmpty) return list;
    try {
      final rows = await _db.from('shipment_contacts').select().inFilter('shipment_id', ids);
      final byId = {for (final r in rows) r['shipment_id'] as String: r};
      return [
        for (final s in list)
          byId[s.id] == null
              ? s
              : s.copyWith(
                  merchantName: byId[s.id]!['merchant_name'] as String?,
                  merchantPhone: byId[s.id]!['merchant_phone'] as String?,
                  driverName: byId[s.id]!['driver_name'] as String?,
                  driverPhone: byId[s.id]!['driver_phone'] as String?,
                )
      ];
    } catch (_) {
      return list;
    }
  }

  // ───────── التاجر ─────────
  @override
  Future<Shipment> createShipment(Shipment d,
      {required String merchantName, required String merchantPhone}) async {
    try {
      // بيانات الاتصال تُعبّأ في الخادم (trigger) من الملف الشخصي، لا من العميل
      final row = await _db.from('shipments').insert(d.toInsertJson()).select().single();
      return Shipment.fromJson(row).copyWith(merchantName: merchantName, merchantPhone: merchantPhone);
    } catch (e) {
      _fail(e);
    }
  }

  @override
  Stream<List<Shipment>> watchMerchantShipments(String merchantId) => _db
      .from('shipments')
      .stream(primaryKey: ['id'])
      .eq('merchant_id', merchantId)
      .order('created_at', ascending: false)
      .asyncMap((rows) => _withContacts(rows.map(Shipment.fromJson).toList()));

  @override
  Stream<Shipment> watchShipment(String id) => _db
      .from('shipments')
      .stream(primaryKey: ['id'])
      .eq('id', id)
      .where((rows) => rows.isNotEmpty)
      .asyncMap((rows) async => (await _withContacts([Shipment.fromJson(rows.first)])).first);

  @override
  Future<void> cancelShipment(String id) async {
    try {
      await _db.from('shipments').update({'status': 'cancelled'}).eq('id', id);
    } catch (e) {
      _fail(e);
    }
  }

  @override
  Future<double> walletBalance(String userId) async {
    final row = await _db.from('wallets').select('balance').eq('user_id', userId).maybeSingle();
    return (row?['balance'] as num?)?.toDouble() ?? 0;
  }

  @override
  Future<double> topUpWallet(String userId, double amount) async {
    try {
      final res = await _db.rpc('wallet_topup', params: {'p_amount': amount});
      return (res as num).toDouble();
    } catch (e) {
      _fail(e);
    }
  }

  @override
  Future<void> payWithWallet(String userId, double amount) async {
    try {
      await _db.rpc('wallet_pay', params: {'p_amount': amount});
    } catch (e) {
      _fail(e);
    }
  }

  // ───────── السائق ─────────
  /// الطلبات المفتوحة. نستخدم Realtime كإشارة «تغيّر شيء» ثم نعيد الجلب من الخادم،
  /// لأن بث Realtime لا يُبلغ السائق حين يأخذ سائق آخر الطلب (يخرج الصف من صلاحياته)
  /// فيبقى الطلب معروضاً عنده. ونضيف مزامنة دورية كل 20 ثانية كشبكة أمان.
  @override
  Stream<List<Shipment>> watchOpenShipments() {
    final controller = StreamController<List<Shipment>>();
    RealtimeChannel? channel;
    Timer? poll;

    Future<void> refresh() async {
      try {
        final rows = await _db
            .from('shipments')
            .select()
            .eq('status', 'open')
            .order('created_at', ascending: false);
        if (!controller.isClosed) controller.add(rows.map(Shipment.fromJson).toList());
      } catch (e) {
        if (!controller.isClosed) controller.addError(e);
      }
    }

    controller.onListen = () {
      refresh();
      poll = Timer.periodic(const Duration(seconds: 20), (_) => refresh());
      channel = _db
          .channel('open-shipments-${DateTime.now().microsecondsSinceEpoch}')
          .onPostgresChanges(
            event: PostgresChangeEvent.all,
            schema: 'public',
            table: 'shipments',
            callback: (_) => refresh(),
          )
          .subscribe();
    };
    controller.onCancel = () async {
      poll?.cancel();
      final ch = channel;
      if (ch != null) await _db.removeChannel(ch);
    };
    return controller.stream;
  }

  @override
  Stream<List<Shipment>> watchDriverShipments(String driverId) => _db
      .from('shipments')
      .stream(primaryKey: ['id'])
      .eq('driver_id', driverId)
      .order('created_at', ascending: false)
      .asyncMap((rows) => _withContacts(rows.map(Shipment.fromJson).toList()));

  /// القبول يتم عبر دالة قاعدة بيانات ذرّية (accept_shipment) لمنع قبول سائقين اثنين للطلب نفسه
  @override
  Future<Shipment> acceptShipment(String id, AppUser driver) async {
    try {
      final res = await _db.rpc('accept_shipment', params: {'p_id': id});
      final s = Shipment.fromJson(Map<String, dynamic>.from(res as Map));
      return (await _withContacts([s])).first;
    } catch (e) {
      _fail(e);
    }
  }

  @override
  Future<void> updateStatus(String id, ShipmentStatus status) async {
    try {
      await _db.from('shipments').update({'status': status.name}).eq('id', id);
    } catch (e) {
      _fail(e);
    }
  }

  @override
  Future<void> pushDriverLocation(String id, double lat, double lng) async {
    await _db.from('shipments').update({
      'driver_lat': lat,
      'driver_lng': lng,
      'driver_updated_at': DateTime.now().toUtc().toIso8601String(),
    }).eq('id', id);
  }

  @override
  Future<String> uploadFile(String bucket, String path, File file) async {
    try {
      await _db.storage.from(bucket).upload(path, file, fileOptions: const FileOptions(upsert: true));
      return path;
    } catch (e) {
      _fail(e);
    }
  }

  @override
  Future<void> submitDriverDocs(String userId, Map<String, String> paths) async {
    try {
      await _db.from('driver_documents').upsert({
        'driver_id': userId,
        'license_path': paths['license'],
        'registration_path': paths['registration'],
        'national_id_path': paths['nationalId'],
      });
    } catch (e) {
      _fail(e);
    }
  }

  @override
  Future<bool> hasSubmittedDocs(String userId) async {
    try {
      final row = await _db.from('driver_documents').select('driver_id').eq('driver_id', userId).maybeSingle();
      return row != null;
    } catch (_) {
      return false;
    }
  }

  @override
  Future<void> completeWithProof(String id, String proofPath) async {
    try {
      await _db.from('shipments').update({'status': 'delivered', 'proof_path': proofPath}).eq('id', id);
    } catch (e) {
      _fail(e);
    }
  }
}
