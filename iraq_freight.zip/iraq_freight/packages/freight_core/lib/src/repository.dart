import 'dart:io';

import 'models.dart';

/// خطأ يُعرض رسالته مباشرة للمستخدم بالعربية
class FreightException implements Exception {
  final String message;

  /// رمز اختياري يميّز الحالات التي تحتاج تصرفاً خاصاً من الواجهة
  final String? code;
  const FreightException(this.message, {this.code});

  /// الطلب قبله سائق آخر قبلك
  static const taken = 'already_taken';
  @override
  String toString() => message;
}

/// واجهة الباكيند المشتركة. لها تنفيذان:
///  - [SupabaseFreightRepository] للإنتاج
///  - [MockFreightRepository] للتجربة بدون خادم
abstract class FreightRepository {
  // ── المصادقة والملف الشخصي ──
  Future<void> sendOtp(String phone);
  Future<AppUser> verifyOtp(String phone, String code);
  Future<AppUser?> currentUser();
  Future<AppUser> saveProfile(AppUser user);
  Future<void> signOut();

  // ── التاجر ──
  Future<Shipment> createShipment(Shipment draft, {required String merchantName, required String merchantPhone});
  Stream<List<Shipment>> watchMerchantShipments(String merchantId);
  Stream<Shipment> watchShipment(String shipmentId);
  Future<void> cancelShipment(String shipmentId);
  Future<double> walletBalance(String userId);
  Future<double> topUpWallet(String userId, double amount);
  Future<void> payWithWallet(String userId, double amount);

  // ── السائق ──
  Stream<List<Shipment>> watchOpenShipments();
  Stream<List<Shipment>> watchDriverShipments(String driverId);
  Future<Shipment> acceptShipment(String shipmentId, AppUser driver);
  Future<void> updateStatus(String shipmentId, ShipmentStatus status);
  Future<void> pushDriverLocation(String shipmentId, double lat, double lng);
  Future<String> uploadFile(String bucket, String path, File file);
  Future<void> submitDriverDocs(String userId, Map<String, String> paths);
  Future<bool> hasSubmittedDocs(String userId);
  Future<void> completeWithProof(String shipmentId, String proofPath);
}
