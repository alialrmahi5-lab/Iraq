import 'package:equatable/equatable.dart';

import 'iraq_data.dart';

/// يحوّل اسماً نصياً قادماً من قاعدة البيانات إلى قيمة enum بأمان
T enumByName<T extends Enum>(List<T> values, Object? name, T fallback) {
  for (final v in values) {
    if (v.name == name) return v;
  }
  return fallback;
}

double _d(dynamic v) => (v as num?)?.toDouble() ?? 0;

// ───────────────────────── التعدادات ─────────────────────────

enum CargoType {
  construction('مواد إنشائية'),
  food('مواد غذائية'),
  electrical('أجهزة كهربائية'),
  wholesale('بضائع جملة عامة'),
  furniture('أثاث');

  const CargoType(this.label);
  final String label;
}

enum VehicleType {
  pickup('بيك آب / كيا'),
  jumbo('جامبو / لوري'),
  trailer('تريلة (قاطرة ومقطورة)');

  const VehicleType(this.label);
  final String label;
}

enum WeightClass {
  small('صغيرة', 'أقل من 2 طن', VehicleType.pickup),
  medium('متوسطة', 'من 2 إلى 7 طن', VehicleType.jumbo),
  large('كبيرة', 'أكثر من 7 طن', VehicleType.trailer);

  const WeightClass(this.label, this.range, this.recommendedVehicle);
  final String label;
  final String range;
  final VehicleType recommendedVehicle;
}

enum ShipmentStatus {
  open('بانتظار سائق'),
  accepted('تم قبول الطلب'),
  atPickup('السائق في موقع التحميل'),
  inTransit('الشحنة في الطريق'),
  atDropoff('السائق وصل نقطة التسليم'),
  delivered('تم التسليم'),
  cancelled('ملغاة');

  const ShipmentStatus(this.label);
  final String label;

  /// طلب لم ينتهِ بعد (لا مكتمل ولا ملغى)
  bool get isActive => this != delivered && this != cancelled;

  /// طلب قبله سائق ولم ينتهِ
  bool get isOngoing => isActive && this != open;
}

enum PaymentMethod {
  zainCash('زين كاش'),
  asiaHawala('آسيا حوالة'),
  card('بطاقة مصرفية / كي كارد / فيزا'),
  cashOnPickup('نقداً عند التحميل'),
  cashOnDelivery('نقداً عند الاستلام'),
  wallet('المحفظة الإلكترونية');

  const PaymentMethod(this.label);
  final String label;
}

enum UserRole { merchant, driver }

enum AccountType {
  company('شركة / معمل'),
  wholesaler('تاجر جملة فردي');

  const AccountType(this.label);
  final String label;
}

enum VerificationStatus { pending, approved, rejected }

// ───────────────────────── المستخدم ─────────────────────────

class AppUser extends Equatable {
  final String id;
  final String phone;
  final UserRole role;
  final String fullName;
  final AccountType? accountType; // للتاجر
  final String? governorate; // للسائق: المحافظة الرئيسية
  final VehicleType? vehicle; // للسائق
  final String? plateNumber; // للسائق
  final VerificationStatus verification;

  const AppUser({
    required this.id,
    required this.phone,
    required this.role,
    this.fullName = '',
    this.accountType,
    this.governorate,
    this.vehicle,
    this.plateNumber,
    this.verification = VerificationStatus.pending,
  });

  /// هل أكمل المستخدم بيانات ملفه الشخصي؟
  bool get profileComplete {
    if (fullName.trim().isEmpty) return false;
    return role == UserRole.merchant
        ? accountType != null
        : governorate != null && vehicle != null && (plateNumber ?? '').isNotEmpty;
  }

  AppUser copyWith({
    String? fullName,
    AccountType? accountType,
    String? governorate,
    VehicleType? vehicle,
    String? plateNumber,
    VerificationStatus? verification,
  }) =>
      AppUser(
        id: id,
        phone: phone,
        role: role,
        fullName: fullName ?? this.fullName,
        accountType: accountType ?? this.accountType,
        governorate: governorate ?? this.governorate,
        vehicle: vehicle ?? this.vehicle,
        plateNumber: plateNumber ?? this.plateNumber,
        verification: verification ?? this.verification,
      );

  factory AppUser.fromJson(Map<String, dynamic> j) => AppUser(
        id: j['id'] as String,
        phone: (j['phone'] ?? '') as String,
        role: enumByName(UserRole.values, j['role'], UserRole.merchant),
        fullName: (j['full_name'] ?? '') as String,
        accountType: j['account_type'] == null
            ? null
            : enumByName(AccountType.values, j['account_type'], AccountType.wholesaler),
        governorate: j['governorate'] as String?,
        vehicle: j['vehicle'] == null
            ? null
            : enumByName(VehicleType.values, j['vehicle'], VehicleType.pickup),
        plateNumber: j['plate_number'] as String?,
        verification:
            enumByName(VerificationStatus.values, j['verification'], VerificationStatus.pending),
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'phone': phone,
        'role': role.name,
        'full_name': fullName,
        'account_type': accountType?.name,
        'governorate': governorate,
        'vehicle': vehicle?.name,
        'plate_number': plateNumber,
      };

  @override
  List<Object?> get props =>
      [id, phone, role, fullName, accountType, governorate, vehicle, plateNumber, verification];
}

// ───────────────────────── الشحنة ─────────────────────────

class Shipment extends Equatable {
  final String id;
  final String merchantId;
  final CargoType cargo;
  final WeightClass weight;
  final VehicleType vehicle;
  final String fromGov;
  final String toGov;
  final double fromLat, fromLng, toLat, toLng;
  final String notes;
  final bool needsRefrigeration;
  final bool insured;
  final double declaredValue;

  // التسعير
  final double distanceKm;
  final double baseFare;
  final double distanceFare;
  final double refrigerationFee;
  final double insuranceFee;
  final double total;
  final double driverNet;
  final PaymentMethod paymentMethod;

  // التنفيذ
  final ShipmentStatus status;
  final String? driverId;
  final double? driverLat, driverLng;
  final String? proofPath;
  final DateTime createdAt;

  // بيانات الاتصال (تأتي من جدول منفصل ولا تظهر إلا للطرفين بعد القبول)
  final String? merchantName, merchantPhone, driverName, driverPhone;

  const Shipment({
    required this.id,
    required this.merchantId,
    required this.cargo,
    required this.weight,
    required this.vehicle,
    required this.fromGov,
    required this.toGov,
    required this.fromLat,
    required this.fromLng,
    required this.toLat,
    required this.toLng,
    this.notes = '',
    this.needsRefrigeration = false,
    this.insured = false,
    this.declaredValue = 0,
    required this.distanceKm,
    required this.baseFare,
    required this.distanceFare,
    this.refrigerationFee = 0,
    this.insuranceFee = 0,
    required this.total,
    required this.driverNet,
    required this.paymentMethod,
    this.status = ShipmentStatus.open,
    this.driverId,
    this.driverLat,
    this.driverLng,
    this.proofPath,
    required this.createdAt,
    this.merchantName,
    this.merchantPhone,
    this.driverName,
    this.driverPhone,
  });

  String get fromName => IraqData.nameOf(fromGov);
  String get toName => IraqData.nameOf(toGov);

  Shipment copyWith({
    ShipmentStatus? status,
    String? driverId,
    double? driverLat,
    double? driverLng,
    String? proofPath,
    String? merchantName,
    String? merchantPhone,
    String? driverName,
    String? driverPhone,
  }) =>
      Shipment(
        id: id,
        merchantId: merchantId,
        cargo: cargo,
        weight: weight,
        vehicle: vehicle,
        fromGov: fromGov,
        toGov: toGov,
        fromLat: fromLat,
        fromLng: fromLng,
        toLat: toLat,
        toLng: toLng,
        notes: notes,
        needsRefrigeration: needsRefrigeration,
        insured: insured,
        declaredValue: declaredValue,
        distanceKm: distanceKm,
        baseFare: baseFare,
        distanceFare: distanceFare,
        refrigerationFee: refrigerationFee,
        insuranceFee: insuranceFee,
        total: total,
        driverNet: driverNet,
        paymentMethod: paymentMethod,
        status: status ?? this.status,
        driverId: driverId ?? this.driverId,
        driverLat: driverLat ?? this.driverLat,
        driverLng: driverLng ?? this.driverLng,
        proofPath: proofPath ?? this.proofPath,
        createdAt: createdAt,
        merchantName: merchantName ?? this.merchantName,
        merchantPhone: merchantPhone ?? this.merchantPhone,
        driverName: driverName ?? this.driverName,
        driverPhone: driverPhone ?? this.driverPhone,
      );

  factory Shipment.fromJson(Map<String, dynamic> j) => Shipment(
        id: j['id'] as String,
        merchantId: j['merchant_id'] as String,
        cargo: enumByName(CargoType.values, j['cargo'], CargoType.wholesale),
        weight: enumByName(WeightClass.values, j['weight'], WeightClass.small),
        vehicle: enumByName(VehicleType.values, j['vehicle'], VehicleType.pickup),
        fromGov: j['from_gov'] as String,
        toGov: j['to_gov'] as String,
        fromLat: _d(j['from_lat']),
        fromLng: _d(j['from_lng']),
        toLat: _d(j['to_lat']),
        toLng: _d(j['to_lng']),
        notes: (j['notes'] ?? '') as String,
        needsRefrigeration: (j['needs_refrigeration'] ?? false) as bool,
        insured: (j['insured'] ?? false) as bool,
        declaredValue: _d(j['declared_value']),
        distanceKm: _d(j['distance_km']),
        baseFare: _d(j['base_fare']),
        distanceFare: _d(j['distance_fare']),
        refrigerationFee: _d(j['refrigeration_fee']),
        insuranceFee: _d(j['insurance_fee']),
        total: _d(j['total']),
        driverNet: _d(j['driver_net']),
        paymentMethod:
            enumByName(PaymentMethod.values, j['payment_method'], PaymentMethod.cashOnDelivery),
        status: enumByName(ShipmentStatus.values, j['status'], ShipmentStatus.open),
        driverId: j['driver_id'] as String?,
        driverLat: (j['driver_lat'] as num?)?.toDouble(),
        driverLng: (j['driver_lng'] as num?)?.toDouble(),
        proofPath: j['proof_path'] as String?,
        createdAt: DateTime.tryParse('${j['created_at']}') ?? DateTime.now(),
      );

  /// بيانات الإدخال عند إنشاء شحنة جديدة (المعرّف والتاريخ يولدهما الخادم)
  Map<String, dynamic> toInsertJson() => {
        'merchant_id': merchantId,
        'cargo': cargo.name,
        'weight': weight.name,
        'vehicle': vehicle.name,
        'from_gov': fromGov,
        'to_gov': toGov,
        'from_lat': fromLat,
        'from_lng': fromLng,
        'to_lat': toLat,
        'to_lng': toLng,
        'notes': notes,
        'needs_refrigeration': needsRefrigeration,
        'insured': insured,
        'declared_value': declaredValue,
        'distance_km': distanceKm,
        'base_fare': baseFare,
        'distance_fare': distanceFare,
        'refrigeration_fee': refrigerationFee,
        'insurance_fee': insuranceFee,
        'total': total,
        'driver_net': driverNet,
        'payment_method': paymentMethod.name,
        'status': 'open',
      };

  @override
  List<Object?> get props => [
        id,
        status,
        driverId,
        driverLat,
        driverLng,
        proofPath,
        driverName,
        driverPhone,
        merchantName,
        merchantPhone,
      ];
}
