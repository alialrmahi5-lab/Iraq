import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'auth_cubit.dart';
import 'models.dart';

/// بوابة المصادقة المشتركة.
/// تعرض: شاشة الهاتف ← شاشة OTP ← [profileBuilder] ← [homeBuilder]
class AuthGate extends StatelessWidget {
  const AuthGate({
    super.key,
    required this.appTitle,
    required this.subtitle,
    required this.icon,
    required this.profileBuilder,
    required this.homeBuilder,
  });

  final String appTitle;
  final String subtitle;
  final IconData icon;
  final Widget Function(BuildContext, AppUser) profileBuilder;
  final Widget Function(BuildContext, AppUser) homeBuilder;

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<AuthCubit, AuthState>(
      listenWhen: (a, b) => b.error != null && a.error != b.error,
      listener: (context, s) => ScaffoldMessenger.of(context)
        ..hideCurrentSnackBar()
        ..showSnackBar(SnackBar(content: Text(s.error!))),
      builder: (context, s) {
        switch (s.status) {
          case AuthStatus.unknown:
            return const Scaffold(body: Center(child: CircularProgressIndicator()));
          case AuthStatus.signedOut:
            return _PhoneScreen(appTitle: appTitle, subtitle: subtitle, icon: icon, state: s);
          case AuthStatus.otpSent:
            return _OtpScreen(state: s);
          case AuthStatus.needsProfile:
            return profileBuilder(context, s.user!);
          case AuthStatus.ready:
            return homeBuilder(context, s.user!);
        }
      },
    );
  }
}

class _PhoneScreen extends StatefulWidget {
  const _PhoneScreen({required this.appTitle, required this.subtitle, required this.icon, required this.state});
  final String appTitle, subtitle;
  final IconData icon;
  final AuthState state;

  @override
  State<_PhoneScreen> createState() => _PhoneScreenState();
}

class _PhoneScreenState extends State<_PhoneScreen> {
  late final _ctrl = TextEditingController(text: widget.state.phone);

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(24),
          children: [
            const SizedBox(height: 40),
            Icon(widget.icon, size: 88, color: cs.primary),
            const SizedBox(height: 16),
            Text(widget.appTitle,
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text(widget.subtitle, textAlign: TextAlign.center, style: Theme.of(context).textTheme.bodyLarge),
            const SizedBox(height: 40),
            TextField(
              controller: _ctrl,
              keyboardType: TextInputType.phone,
              textDirection: TextDirection.ltr,
              style: const TextStyle(fontSize: 22, letterSpacing: 1.5),
              inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'[0-9+]'))],
              decoration: const InputDecoration(labelText: 'رقم الهاتف', hintText: '07701234567', prefixIcon: Icon(Icons.phone_iphone)),
            ),
            const SizedBox(height: 20),
            FilledButton(
              onPressed: widget.state.busy ? null : () => context.read<AuthCubit>().sendOtp(_ctrl.text),
              child: widget.state.busy
                  ? const SizedBox(height: 22, width: 22, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Text('إرسال رمز التحقق'),
            ),
          ],
        ),
      ),
    );
  }
}

class _OtpScreen extends StatefulWidget {
  const _OtpScreen({required this.state});
  final AuthState state;

  @override
  State<_OtpScreen> createState() => _OtpScreenState();
}

class _OtpScreenState extends State<_OtpScreen> {
  final _ctrl = TextEditingController();

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('رمز التحقق'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back), // ينعكس تلقائياً في الاتجاه RTL
          onPressed: () => context.read<AuthCubit>().backToPhone(),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          Text('أرسلنا رمزاً من 6 أرقام إلى', textAlign: TextAlign.center, style: Theme.of(context).textTheme.bodyLarge),
          const SizedBox(height: 4),
          Text(widget.state.phone,
              textAlign: TextAlign.center,
              textDirection: TextDirection.ltr,
              style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
          const SizedBox(height: 28),
          TextField(
            controller: _ctrl,
            autofocus: true,
            maxLength: 6,
            keyboardType: TextInputType.number,
            textAlign: TextAlign.center,
            textDirection: TextDirection.ltr,
            style: const TextStyle(fontSize: 32, letterSpacing: 12, fontWeight: FontWeight.bold),
            inputFormatters: [FilteringTextInputFormatter.digitsOnly],
            decoration: const InputDecoration(counterText: ''),
            onChanged: (v) {
              if (v.length == 6) context.read<AuthCubit>().verifyOtp(v);
            },
          ),
          const SizedBox(height: 20),
          FilledButton(
            onPressed: widget.state.busy ? null : () => context.read<AuthCubit>().verifyOtp(_ctrl.text),
            child: widget.state.busy
                ? const SizedBox(height: 22, width: 22, child: CircularProgressIndicator(strokeWidth: 2))
                : const Text('تأكيد'),
          ),
          const SizedBox(height: 12),
          TextButton(
            onPressed: () => context.read<AuthCubit>().sendOtp(widget.state.phone),
            child: const Text('إعادة إرسال الرمز'),
          ),
        ],
      ),
    );
  }
}
