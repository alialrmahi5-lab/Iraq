import 'package:flutter/widgets.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'config.dart';
import 'mock_repository.dart';
import 'models.dart';
import 'repository.dart';
import 'supabase_repository.dart';

/// يهيّئ الباكيند المناسب (Supabase أو التجريبي) حسب مفاتيح --dart-define
Future<FreightRepository> bootstrapBackend(UserRole role) async {
  WidgetsFlutterBinding.ensureInitialized();
  if (AppConfig.useMock) return MockFreightRepository(role);
  await Supabase.initialize(url: AppConfig.supabaseUrl, anonKey: AppConfig.supabaseAnonKey);
  return SupabaseFreightRepository(role);
}
