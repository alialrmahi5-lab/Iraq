import 'package:intl/intl.dart';
import 'package:url_launcher/url_launcher.dart';

/// تنسيق مبلغ بالدينار العراقي: 1,250,000 د.ع
String formatIqd(num v) => '${NumberFormat('#,###', 'en').format(v.round())} د.ع';

/// يحوّل رقماً عراقياً (07xxxxxxxxx) إلى الصيغة الدولية (+9647xxxxxxxxx)
String toE164(String raw) {
  var d = raw.replaceAll(RegExp(r'[^0-9+]'), '');
  if (d.startsWith('+')) return d;
  if (d.startsWith('00')) return '+${d.substring(2)}';
  if (d.startsWith('964')) return '+$d';
  if (d.startsWith('0')) d = d.substring(1);
  return '+964$d';
}

/// اتصال هاتفي مباشر
Future<bool> callPhone(String phone) =>
    launchUrl(Uri.parse('tel:${toE164(phone)}'), mode: LaunchMode.externalApplication);

/// فتح محادثة واتساب
Future<bool> openWhatsApp(String phone, {String text = ''}) {
  final n = toE164(phone).substring(1);
  final uri = Uri.parse('https://wa.me/$n${text.isEmpty ? '' : '?text=${Uri.encodeComponent(text)}'}');
  return launchUrl(uri, mode: LaunchMode.externalApplication);
}

/// فتح الملاحة إلى إحداثيات في خرائط جوجل
Future<bool> openNavigation(double lat, double lng) => launchUrl(
      Uri.parse('https://www.google.com/maps/dir/?api=1&destination=$lat,$lng&travelmode=driving'),
      mode: LaunchMode.externalApplication,
    );
