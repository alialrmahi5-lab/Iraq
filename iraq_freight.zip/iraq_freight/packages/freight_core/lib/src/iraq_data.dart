import 'dart:math' as math;

/// محافظة عراقية مع إحداثيات مركزها
class Governorate {
  final String id;
  final String nameAr;
  final double lat;
  final double lng;
  const Governorate(this.id, this.nameAr, this.lat, this.lng);
}

class IraqData {
  static const governorates = <Governorate>[
    Governorate('baghdad', 'بغداد', 33.3152, 44.3661),
    Governorate('nineveh', 'نينوى', 36.3350, 43.1189),
    Governorate('basra', 'البصرة', 30.5085, 47.7804),
    Governorate('erbil', 'أربيل', 36.1912, 44.0092),
    Governorate('sulaymaniyah', 'السليمانية', 35.5558, 45.4351),
    Governorate('duhok', 'دهوك', 36.8669, 42.9503),
    Governorate('kirkuk', 'كركوك', 35.4681, 44.3922),
    Governorate('anbar', 'الأنبار', 33.4258, 43.2992),
    Governorate('diyala', 'ديالى', 33.7500, 44.6333),
    Governorate('salahuddin', 'صلاح الدين', 34.6071, 43.6782),
    Governorate('babil', 'بابل', 32.4721, 44.4210),
    Governorate('karbala', 'كربلاء', 32.6160, 44.0249),
    Governorate('najaf', 'النجف', 32.0000, 44.3333),
    Governorate('wasit', 'واسط', 32.5128, 45.8182),
    Governorate('dhiqar', 'ذي قار', 31.0580, 46.2573),
    Governorate('maysan', 'ميسان', 31.8356, 47.1450),
    Governorate('muthanna', 'المثنى', 31.3094, 45.2833),
    Governorate('qadisiyyah', 'القادسية', 31.9889, 44.9250),
  ];

  static Governorate byId(String id) =>
      governorates.firstWhere((g) => g.id == id, orElse: () => governorates.first);

  static String nameOf(String id) => byId(id).nameAr;

  /// معامل تحويل المسافة الجوية إلى مسافة طرق تقريبية
  static const _roadFactor = 1.28;

  /// مسافات طرق تقريبية معروفة (كم) تُفضَّل على التقدير الحسابي.
  /// المفتاح: معرّفا المحافظتين مرتبان أبجدياً ومفصولان بـ |
  static const _overrides = <String, double>{
    'baghdad|basra': 550,
    'baghdad|erbil': 350,
    'baghdad|najaf': 160,
    'baghdad|nineveh': 400,
    'baghdad|karbala': 100,
  };

  /// المسافة بالكيلومتر بين مركزي محافظتين (تقديرية).
  /// للدقة العالية استبدلها لاحقاً بـ Google Distance Matrix من جهة الخادم.
  static double distanceKm(String a, String b) {
    if (a == b) return 40; // نقل داخل نفس المحافظة
    final key = ([a, b]..sort()).join('|');
    final known = _overrides[key];
    if (known != null) return known;
    final ga = byId(a), gb = byId(b);
    return (haversineKm(ga.lat, ga.lng, gb.lat, gb.lng) * _roadFactor).roundToDouble();
  }

  /// المحافظات القريبة (ضمن withinKm) من محافظة معينة، دون المحافظة نفسها
  static List<String> nearby(String id, {double withinKm = 130}) => governorates
      .where((g) => g.id != id && distanceKm(id, g.id) <= withinKm)
      .map((g) => g.id)
      .toList();

  static double haversineKm(double lat1, double lng1, double lat2, double lng2) {
    const r = 6371.0;
    double rad(double d) => d * math.pi / 180;
    final dLat = rad(lat2 - lat1), dLng = rad(lng2 - lng1);
    final h = math.pow(math.sin(dLat / 2), 2) +
        math.cos(rad(lat1)) * math.cos(rad(lat2)) * math.pow(math.sin(dLng / 2), 2);
    return 2 * r * math.asin(math.sqrt(h));
  }
}
