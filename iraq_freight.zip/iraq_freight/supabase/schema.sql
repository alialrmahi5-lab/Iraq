-- ============================================================================
--  نظام شحن العراق: مخطط قاعدة بيانات Supabase
--  الصقه كاملاً في: Supabase Dashboard → SQL Editor → Run
-- ============================================================================
--  أمان الصفوف (RLS) مفعّل على كل الجداول. الأفكار الأساسية:
--   • التاجر يرى شحناته فقط، والسائق المعتمد يرى الطلبات المفتوحة وشحناته فقط.
--   • قبول الطلب يتم عبر دالة ذرّية accept_shipment فلا يقبله سائقان.
--   • بيانات الاتصال (هاتف التاجر/السائق) في جدول منفصل لا يراه السائق قبل القبول.
--   • السائق لا يستطيع تغيير حالة اعتماده بنفسه؛ الإدارة تعتمده يدوياً (آخر الملف).
-- ============================================================================

create extension if not exists pgcrypto;

-- ───────────────────────── الملفات الشخصية ─────────────────────────
create table if not exists public.profiles (
  id             uuid primary key references auth.users(id) on delete cascade,
  phone          text not null default '',
  role           text not null check (role in ('merchant', 'driver')),
  full_name      text not null default '',
  account_type   text check (account_type in ('company', 'wholesaler')),
  governorate    text,
  vehicle        text check (vehicle in ('pickup', 'jumbo', 'trailer')),
  plate_number   text,
  verification   text not null default 'pending'
                   check (verification in ('pending', 'approved', 'rejected')),
  created_at     timestamptz not null default now()
);

alter table public.profiles enable row level security;

drop policy if exists profiles_select_own on public.profiles;
create policy profiles_select_own on public.profiles
  for select to authenticated using (id = auth.uid());

drop policy if exists profiles_insert_own on public.profiles;
create policy profiles_insert_own on public.profiles
  for insert to authenticated with check (id = auth.uid());

drop policy if exists profiles_update_own on public.profiles;
create policy profiles_update_own on public.profiles
  for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

-- حماية الحقول الحساسة: لا يغيّر المستخدم دوره أو اعتماده أو هاتفه المسجَّل
create or replace function public.profiles_guard()
returns trigger language plpgsql security definer set search_path = public as $$
declare v_phone text;
begin
  if coalesce(auth.role(), 'service_role') <> 'authenticated' then
    return new;  -- الإدارة (SQL Editor / service_role) غير مقيّدة
  end if;

  if tg_op = 'INSERT' then
    new.verification := 'pending';
    -- الهاتف يؤخذ من حساب المصادقة لا من العميل
    select '+' || u.phone into v_phone from auth.users u where u.id = new.id and u.phone is not null;
    if v_phone is not null then new.phone := v_phone; end if;
  else
    new.id           := old.id;
    new.role         := old.role;
    new.phone        := old.phone;
    new.verification := old.verification;
  end if;
  return new;
end $$;

drop trigger if exists trg_profiles_guard on public.profiles;
create trigger trg_profiles_guard before insert or update on public.profiles
  for each row execute function public.profiles_guard();

-- ───────────────────────── وثائق السائق ─────────────────────────
create table if not exists public.driver_documents (
  driver_id         uuid primary key references public.profiles(id) on delete cascade,
  license_path      text,
  registration_path text,
  national_id_path  text,
  submitted_at      timestamptz not null default now()
);

alter table public.driver_documents enable row level security;

drop policy if exists docs_select_own on public.driver_documents;
create policy docs_select_own on public.driver_documents
  for select to authenticated using (driver_id = auth.uid());
drop policy if exists docs_insert_own on public.driver_documents;
create policy docs_insert_own on public.driver_documents
  for insert to authenticated with check (driver_id = auth.uid());
drop policy if exists docs_update_own on public.driver_documents;
create policy docs_update_own on public.driver_documents
  for update to authenticated using (driver_id = auth.uid()) with check (driver_id = auth.uid());

-- إعادة رفع الوثائق بعد الرفض تعيد الحساب إلى «قيد المراجعة»
create or replace function public.docs_resubmitted()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  update public.profiles set verification = 'pending'
   where id = new.driver_id and verification = 'rejected';
  return new;
end $$;

drop trigger if exists trg_docs_resubmitted on public.driver_documents;
create trigger trg_docs_resubmitted after insert or update on public.driver_documents
  for each row execute function public.docs_resubmitted();

-- ───────────────────────── الشحنات ─────────────────────────
create table if not exists public.shipments (
  id                 uuid primary key default gen_random_uuid(),
  merchant_id        uuid not null references public.profiles(id),
  cargo              text not null check (cargo in ('construction','food','electrical','wholesale','furniture')),
  weight             text not null check (weight in ('small','medium','large')),
  vehicle            text not null check (vehicle in ('pickup','jumbo','trailer')),
  from_gov           text not null,
  to_gov             text not null,
  from_lat           double precision not null,
  from_lng           double precision not null,
  to_lat             double precision not null,
  to_lng             double precision not null,
  notes              text not null default '',
  needs_refrigeration boolean not null default false,
  insured            boolean not null default false,
  declared_value     numeric not null default 0 check (declared_value >= 0),

  distance_km        numeric not null check (distance_km >= 0),
  base_fare          numeric not null check (base_fare >= 0),
  distance_fare      numeric not null check (distance_fare >= 0),
  refrigeration_fee  numeric not null default 0 check (refrigeration_fee >= 0),
  insurance_fee      numeric not null default 0 check (insurance_fee >= 0),
  total              numeric not null check (total >= 0),
  driver_net         numeric not null check (driver_net >= 0 and driver_net <= total),
  payment_method     text not null
                       check (payment_method in ('zainCash','asiaHawala','card','cashOnPickup','cashOnDelivery','wallet')),

  status             text not null default 'open'
                       check (status in ('open','accepted','atPickup','inTransit','atDropoff','delivered','cancelled')),
  driver_id          uuid references public.profiles(id),
  driver_lat         double precision,
  driver_lng         double precision,
  driver_updated_at  timestamptz,
  proof_path         text,
  created_at         timestamptz not null default now()
);

create index if not exists shipments_open_idx     on public.shipments (created_at desc) where status = 'open';
create index if not exists shipments_merchant_idx on public.shipments (merchant_id, created_at desc);
create index if not exists shipments_driver_idx   on public.shipments (driver_id, created_at desc);

alter table public.shipments enable row level security;

-- القراءة
drop policy if exists shipments_select_merchant on public.shipments;
create policy shipments_select_merchant on public.shipments
  for select to authenticated using (merchant_id = auth.uid());

drop policy if exists shipments_select_driver on public.shipments;
create policy shipments_select_driver on public.shipments
  for select to authenticated using (driver_id = auth.uid());

drop policy if exists shipments_select_open on public.shipments;
create policy shipments_select_open on public.shipments
  for select to authenticated using (
    status = 'open' and exists (
      select 1 from public.profiles p
       where p.id = auth.uid() and p.role = 'driver' and p.verification = 'approved')
  );

-- الإنشاء: التاجر فقط، وبحالة open وبلا سائق
drop policy if exists shipments_insert_merchant on public.shipments;
create policy shipments_insert_merchant on public.shipments
  for insert to authenticated with check (
    merchant_id = auth.uid() and status = 'open' and driver_id is null
    and exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'merchant')
  );

-- التعديل: أي من الطرفين على صفوفه فقط (تفاصيل المسموح في trigger أدناه)
drop policy if exists shipments_update_merchant on public.shipments;
create policy shipments_update_merchant on public.shipments
  for update to authenticated using (merchant_id = auth.uid()) with check (merchant_id = auth.uid());

drop policy if exists shipments_update_driver on public.shipments;
create policy shipments_update_driver on public.shipments
  for update to authenticated using (driver_id = auth.uid()) with check (driver_id = auth.uid());

-- صلاحيات الأعمدة: العميل لا يعدّل الأسعار ولا driver_id مباشرة
revoke all on public.shipments from anon, authenticated;
grant select on public.shipments to authenticated;
grant insert (merchant_id, cargo, weight, vehicle, from_gov, to_gov, from_lat, from_lng, to_lat, to_lng,
              notes, needs_refrigeration, insured, declared_value, distance_km, base_fare, distance_fare,
              refrigeration_fee, insurance_fee, total, driver_net, payment_method, status)
  on public.shipments to authenticated;
grant update (status, driver_lat, driver_lng, driver_updated_at, proof_path)
  on public.shipments to authenticated;

-- حارس الانتقالات: يضمن تسلسل الحالات ويمنع التلاعب
create or replace function public.shipments_guard()
returns trigger language plpgsql security definer set search_path = public as $$
declare uid uuid := auth.uid();
begin
  if coalesce(auth.role(), 'service_role') <> 'authenticated' then
    return new;
  end if;

  -- مسار القبول (دالة accept_shipment)
  if old.status = 'open' and new.status = 'accepted' and old.driver_id is null and new.driver_id = uid then
    return new;
  end if;

  if uid = old.merchant_id then
    -- التاجر يستطيع فقط إلغاء طلب لم يقبله سائق
    if old.status = 'open' and new.status = 'cancelled'
       and new.driver_id  is not distinct from old.driver_id
       and new.proof_path is not distinct from old.proof_path
       and new.driver_lat is not distinct from old.driver_lat
       and new.driver_lng is not distinct from old.driver_lng then
      return new;
    end if;
    raise exception 'forbidden_merchant_update';

  elsif uid = old.driver_id then
    if new.driver_id is distinct from old.driver_id then raise exception 'forbidden'; end if;
    if new.status = old.status  -- تحديث موقع فقط
       or (old.status = 'accepted' and new.status = 'atPickup')
       or (old.status = 'atPickup' and new.status = 'inTransit')
       or (old.status = 'inTransit' and new.status = 'atDropoff')
       or (old.status = 'atDropoff' and new.status = 'delivered' and new.proof_path is not null) then
      return new;
    end if;
    raise exception 'invalid_status_transition';
  end if;

  raise exception 'forbidden';
end $$;

drop trigger if exists trg_shipments_guard on public.shipments;
create trigger trg_shipments_guard before update on public.shipments
  for each row execute function public.shipments_guard();

-- ───────────────────────── بيانات الاتصال ─────────────────────────
-- جدول منفصل: هاتف التاجر لا يظهر للسائق إلا بعد قبوله الطلب
create table if not exists public.shipment_contacts (
  shipment_id    uuid primary key references public.shipments(id) on delete cascade,
  merchant_name  text,
  merchant_phone text,
  driver_name    text,
  driver_phone   text
);

alter table public.shipment_contacts enable row level security;

drop policy if exists contacts_select_parties on public.shipment_contacts;
create policy contacts_select_parties on public.shipment_contacts
  for select to authenticated using (
    exists (select 1 from public.shipments s
             where s.id = shipment_id and (s.merchant_id = auth.uid() or s.driver_id = auth.uid()))
  );
revoke insert, update, delete on public.shipment_contacts from anon, authenticated;

-- تُعبّأ تلقائياً من الملف الشخصي عند إنشاء الشحنة (لا يرسلها العميل)
create or replace function public.shipments_after_insert()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.shipment_contacts (shipment_id, merchant_name, merchant_phone)
  select new.id, p.full_name, p.phone from public.profiles p where p.id = new.merchant_id;
  return new;
end $$;

drop trigger if exists trg_shipments_after_insert on public.shipments;
create trigger trg_shipments_after_insert after insert on public.shipments
  for each row execute function public.shipments_after_insert();

-- ───────────────────────── قبول الطلب (ذرّي) ─────────────────────────
create or replace function public.accept_shipment(p_id uuid)
returns public.shipments language plpgsql security definer set search_path = public as $$
declare
  v_drv public.profiles;
  v_row public.shipments;
begin
  select * into v_drv from public.profiles where id = auth.uid();
  if v_drv.id is null or v_drv.role <> 'driver' or v_drv.verification <> 'approved' then
    raise exception 'driver_not_approved';
  end if;

  -- UPDATE ... WHERE status='open' يقفل الصف: السائق الثاني لن يجد الصف مفتوحاً
  update public.shipments
     set status = 'accepted', driver_id = auth.uid()
   where id = p_id and status = 'open' and vehicle = v_drv.vehicle
   returning * into v_row;

  if v_row.id is null then
    raise exception 'already_taken';
  end if;

  update public.shipment_contacts
     set driver_name = v_drv.full_name, driver_phone = v_drv.phone
   where shipment_id = p_id;

  return v_row;
end $$;

-- ───────────────────────── المحفظة ─────────────────────────
create table if not exists public.wallets (
  user_id    uuid primary key references public.profiles(id) on delete cascade,
  balance    numeric not null default 0 check (balance >= 0),
  updated_at timestamptz not null default now()
);

alter table public.wallets enable row level security;
drop policy if exists wallets_select_own on public.wallets;
create policy wallets_select_own on public.wallets
  for select to authenticated using (user_id = auth.uid());
revoke insert, update, delete on public.wallets from anon, authenticated;

-- ⚠️⚠️ تجريبية فقط (DEMO): تضيف رصيداً بلا أي دفع حقيقي!
-- قبل الإطلاق احذف هذه الدالة، وأضف الرصيد من Edge Function / Webhook
-- بعد تأكيد الدفع من بوابة (زين كاش / آسيا حوالة / كي كارد) بصلاحية service_role.
create or replace function public.wallet_topup(p_amount numeric)
returns numeric language plpgsql security definer set search_path = public as $$
declare v numeric;
begin
  if p_amount is null or p_amount <= 0 or p_amount > 5000000 then
    raise exception 'invalid_amount';
  end if;
  insert into public.wallets (user_id, balance) values (auth.uid(), p_amount)
  on conflict (user_id) do update set balance = public.wallets.balance + p_amount, updated_at = now()
  returning balance into v;
  return v;
end $$;

create or replace function public.wallet_pay(p_amount numeric)
returns numeric language plpgsql security definer set search_path = public as $$
declare v numeric;
begin
  if p_amount is null or p_amount <= 0 then raise exception 'invalid_amount'; end if;
  update public.wallets set balance = balance - p_amount, updated_at = now()
   where user_id = auth.uid() and balance >= p_amount
   returning balance into v;
  if v is null then raise exception 'insufficient_funds'; end if;
  return v;
end $$;

-- الدوال متاحة للمستخدمين المسجّلين فقط
revoke execute on function public.accept_shipment(uuid)  from public, anon;
revoke execute on function public.wallet_topup(numeric)  from public, anon;
revoke execute on function public.wallet_pay(numeric)    from public, anon;
grant  execute on function public.accept_shipment(uuid)  to authenticated;
grant  execute on function public.wallet_topup(numeric)  to authenticated;
grant  execute on function public.wallet_pay(numeric)    to authenticated;

-- ───────────────────────── التخزين (صور الوثائق والوصولات) ─────────────────────────
insert into storage.buckets (id, name, public)
values ('driver-docs', 'driver-docs', false), ('delivery-proofs', 'delivery-proofs', false)
on conflict (id) do nothing;

-- كل مستخدم يرفع ويقرأ داخل مجلده فقط: <user_id>/اسم_الملف
drop policy if exists "own folder write" on storage.objects;
create policy "own folder write" on storage.objects
  for insert to authenticated with check (
    bucket_id in ('driver-docs', 'delivery-proofs')
    and (storage.foldername(name))[1] = auth.uid()::text);

drop policy if exists "own folder update" on storage.objects;
create policy "own folder update" on storage.objects
  for update to authenticated using (
    bucket_id in ('driver-docs', 'delivery-proofs')
    and (storage.foldername(name))[1] = auth.uid()::text);

drop policy if exists "own folder read" on storage.objects;
create policy "own folder read" on storage.objects
  for select to authenticated using (
    bucket_id in ('driver-docs', 'delivery-proofs')
    and (storage.foldername(name))[1] = auth.uid()::text);

-- التاجر يقرأ وصل التسليم الخاص بشحنته
drop policy if exists "merchant reads proof" on storage.objects;
create policy "merchant reads proof" on storage.objects
  for select to authenticated using (
    bucket_id = 'delivery-proofs'
    and exists (select 1 from public.shipments s where s.proof_path = name and s.merchant_id = auth.uid()));

-- ───────────────────────── البث الحي (Realtime) ─────────────────────────
do $$
begin
  if not exists (select 1 from pg_publication_tables
                  where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'shipments') then
    alter publication supabase_realtime add table public.shipments;
  end if;
end $$;

-- ============================================================================
--  إدارة السائقين (من SQL Editor، بصلاحية الإدارة)
-- ============================================================================
--  عرض السائقين بانتظار المراجعة مع مسارات وثائقهم (تُعرض الصور من Storage → driver-docs):
--    select p.id, p.full_name, p.phone, p.plate_number, d.*
--      from profiles p join driver_documents d on d.driver_id = p.id
--     where p.verification = 'pending';
--
--  اعتماد سائق:   update profiles set verification = 'approved' where id = '<uuid>';
--  رفض سائق:      update profiles set verification = 'rejected' where id = '<uuid>';
-- ============================================================================
