import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:freight_core/freight_core.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

/// حالة استمارة الحجز متعددة الخطوات
class BookingState extends Equatable {
  final int step; // 0 البضاعة · 1 المسار · 2 التفاصيل · 3 السعر
  final CargoType? cargo;
  final WeightClass? weight;
  final VehicleType? vehicle;
  final String? fromGov, toGov;
  final LatLng? fromPin, toPin;
  final String notes;
  final bool refrigerated;
  final bool insured;
  final double declaredValue;
  final PaymentMethod payment;
  final bool submitting;
  final String? error;
  final Shipment? created;

  const BookingState({
    this.step = 0,
    this.cargo,
    this.weight,
    this.vehicle,
    this.fromGov,
    this.toGov,
    this.fromPin,
    this.toPin,
    this.notes = '',
    this.refrigerated = false,
    this.insured = false,
    this.declaredValue = 0,
    this.payment = PaymentMethod.cashOnDelivery,
    this.submitting = false,
    this.error,
    this.created,
  });

  /// عرض السعر المحسوب لحظياً (null حتى تكتمل المحافظتان والمركبة)
  PriceQuote? get quote => (fromGov != null && toGov != null && vehicle != null)
      ? PriceEngine.quote(
          fromGov: fromGov!,
          toGov: toGov!,
          vehicle: vehicle!,
          needsRefrigeration: refrigerated,
          insured: insured,
          declaredValue: declaredValue,
        )
      : null;

  /// هل الخطوة الحالية مكتملة ليُسمح بالانتقال؟
  bool get canContinue => switch (step) {
        0 => cargo != null && weight != null && vehicle != null,
        1 => fromGov != null && toGov != null && fromGov != toGov && fromPin != null && toPin != null,
        2 => true,
        _ => !insured || declaredValue > 0,
      };

  BookingState copyWith({
    int? step,
    CargoType? cargo,
    WeightClass? weight,
    VehicleType? vehicle,
    String? fromGov,
    String? toGov,
    LatLng? fromPin,
    LatLng? toPin,
    String? notes,
    bool? refrigerated,
    bool? insured,
    double? declaredValue,
    PaymentMethod? payment,
    bool? submitting,
    String? error,
    Shipment? created,
  }) =>
      BookingState(
        step: step ?? this.step,
        cargo: cargo ?? this.cargo,
        weight: weight ?? this.weight,
        vehicle: vehicle ?? this.vehicle,
        fromGov: fromGov ?? this.fromGov,
        toGov: toGov ?? this.toGov,
        fromPin: fromPin ?? this.fromPin,
        toPin: toPin ?? this.toPin,
        notes: notes ?? this.notes,
        refrigerated: refrigerated ?? this.refrigerated,
        insured: insured ?? this.insured,
        declaredValue: declaredValue ?? this.declaredValue,
        payment: payment ?? this.payment,
        submitting: submitting ?? false,
        error: error,
        created: created ?? this.created,
      );

  @override
  List<Object?> get props => [
        step, cargo, weight, vehicle, fromGov, toGov, fromPin, toPin, notes,
        refrigerated, insured, declaredValue, payment, submitting, error, created,
      ];
}

class BookingCubit extends Cubit<BookingState> {
  BookingCubit(this._repo) : super(const BookingState());
  final FreightRepository _repo;

  // ── الخطوة 0 ──
  void setCargo(CargoType v) => emit(state.copyWith(cargo: v));

  /// اختيار الوزن يقترح المركبة تلقائياً، ويمكن للتاجر تغييرها
  void setWeight(WeightClass v) => emit(state.copyWith(weight: v, vehicle: v.recommendedVehicle));
  void setVehicle(VehicleType v) => emit(state.copyWith(vehicle: v));

  // ── الخطوة 1 ── اختيار المحافظة يضع الدبوس في مركزها، ثم يدقّقه التاجر على الخريطة
  void setFromGov(String id) {
    final g = IraqData.byId(id);
    emit(state.copyWith(fromGov: id, fromPin: LatLng(g.lat, g.lng)));
  }

  void setToGov(String id) {
    final g = IraqData.byId(id);
    emit(state.copyWith(toGov: id, toPin: LatLng(g.lat, g.lng)));
  }

  void setFromPin(LatLng p) => emit(state.copyWith(fromPin: p));
  void setToPin(LatLng p) => emit(state.copyWith(toPin: p));

  // ── الخطوة 2 و 3 ──
  void setNotes(String v) => emit(state.copyWith(notes: v));
  void setRefrigerated(bool v) => emit(state.copyWith(refrigerated: v));
  void setInsured(bool v) => emit(state.copyWith(insured: v));
  void setDeclaredValue(double v) => emit(state.copyWith(declaredValue: v));
  void setPayment(PaymentMethod m) => emit(state.copyWith(payment: m));

  void next() {
    if (state.canContinue && state.step < 3) emit(state.copyWith(step: state.step + 1));
  }

  void back() {
    if (state.step > 0) emit(state.copyWith(step: state.step - 1));
  }

  /// تأكيد الحجز: ينشئ الشحنة ثم يدفع (المحفظة تُخصم فعلاً، والبوابات الإلكترونية محاكاة)
  Future<void> submit(AppUser user) async {
    final q = state.quote;
    if (q == null || state.submitting) return;
    emit(state.copyWith(submitting: true));
    try {
      final draft = Shipment(
        id: '',
        merchantId: user.id,
        cargo: state.cargo!,
        weight: state.weight!,
        vehicle: state.vehicle!,
        fromGov: state.fromGov!,
        toGov: state.toGov!,
        fromLat: state.fromPin!.latitude,
        fromLng: state.fromPin!.longitude,
        toLat: state.toPin!.latitude,
        toLng: state.toPin!.longitude,
        notes: state.notes.trim(),
        needsRefrigeration: state.refrigerated,
        insured: state.insured,
        declaredValue: state.declaredValue,
        distanceKm: q.distanceKm,
        baseFare: q.baseFare,
        distanceFare: q.distanceFare,
        refrigerationFee: q.refrigerationFee,
        insuranceFee: q.insuranceFee,
        total: q.total,
        driverNet: q.driverNet,
        paymentMethod: state.payment,
        createdAt: DateTime.now(),
      );
      final s = await _repo.createShipment(draft, merchantName: user.fullName, merchantPhone: user.phone);

      switch (state.payment) {
        case PaymentMethod.wallet:
          try {
            await _repo.payWithWallet(user.id, q.total);
          } on FreightException {
            await _repo.cancelShipment(s.id); // تراجع إن فشل الخصم
            rethrow;
          }
        case PaymentMethod.zainCash:
        case PaymentMethod.asiaHawala:
        case PaymentMethod.card:
          // TODO: اربط بوابة الدفع الفعلية هنا (زين كاش / آسيا حوالة / كي كارد).
          await Future.delayed(const Duration(milliseconds: 1500)); // محاكاة
        case PaymentMethod.cashOnPickup:
        case PaymentMethod.cashOnDelivery:
          break;
      }
      emit(state.copyWith(created: s));
    } on FreightException catch (e) {
      emit(state.copyWith(error: e.message));
    }
  }
}
