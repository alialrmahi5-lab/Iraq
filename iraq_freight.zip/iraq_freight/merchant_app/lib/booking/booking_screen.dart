import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:freight_core/freight_core.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

import '../payment/payment_widgets.dart';
import 'booking_cubit.dart';
import 'map_picker.dart';

const _stepTitles = ['البضاعة والسيارة', 'مسار الرحلة', 'تفاصيل إضافية', 'السعر والدفع'];

/// استمارة حجز شحنة من 4 خطوات. تُرجع [Shipment] عند نجاح الحجز.
class BookingScreen extends StatelessWidget {
  const BookingScreen({super.key, required this.user});
  final AppUser user;

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (ctx) => BookingCubit(ctx.read<FreightRepository>()),
      child: _BookingView(user: user),
    );
  }
}

class _BookingView extends StatefulWidget {
  const _BookingView({required this.user});
  final AppUser user;

  @override
  State<_BookingView> createState() => _BookingViewState();
}

class _BookingViewState extends State<_BookingView> {
  final _notes = TextEditingController();
  final _value = TextEditingController();
  double? _wallet;

  @override
  void initState() {
    super.initState();
    context
        .read<FreightRepository>()
        .walletBalance(widget.user.id)
        .then((v) {
          if (mounted) setState(() => _wallet = v);
        })
        .catchError((_) {});
  }

  @override
  void dispose() {
    _notes.dispose();
    _value.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<BookingCubit, BookingState>(
      listenWhen: (a, b) => a.created != b.created || (b.error != null && a.error != b.error),
      listener: (context, s) {
        if (s.created != null) {
          Navigator.pop(context, s.created);
        } else if (s.error != null) {
          ScaffoldMessenger.of(context)
            ..hideCurrentSnackBar()
            ..showSnackBar(SnackBar(content: Text(s.error!)));
        }
      },
      builder: (context, s) {
        final c = context.read<BookingCubit>();
        final total = s.quote?.total ?? 0;
        final walletShort = s.payment == PaymentMethod.wallet && (_wallet ?? 0) < total;
        return PopScope(
          // زر الرجوع يعود للخطوة السابقة بدل إغلاق الاستمارة
          canPop: s.step == 0,
          onPopInvokedWithResult: (didPop, _) {
            if (!didPop) c.back();
          },
          child: Scaffold(
            appBar: AppBar(title: const Text('حجز شحنة جديدة'), actions: const [ThemeToggleButton()]),
            body: Column(children: [
              _StepHeader(step: s.step),
              Expanded(
                child: ListView(
                  padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
                  children: [
                    switch (s.step) {
                      0 => _step0(s, c),
                      1 => _step1(context, s, c),
                      2 => _step2(s, c),
                      _ => _step3(s, c),
                    },
                  ],
                ),
              ),
              _BottomBar(
                state: s,
                disabledExtra: walletShort,
                onBack: c.back,
                onNext: c.next,
                onSubmit: () => c.submit(widget.user),
              ),
            ]),
          ),
        );
      },
    );
  }

  // ───────────── الخطوة 1: البضاعة والسيارة ─────────────
  Widget _step0(BookingState s, BookingCubit c) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const _Title('صنف البضاعة'),
      Wrap(spacing: 8, runSpacing: 8, children: [
        for (final t in CargoType.values)
          ChoiceChip(label: Text(t.label), selected: s.cargo == t, onSelected: (_) => c.setCargo(t)),
      ]),
      const SizedBox(height: 24),
      const _Title('حجم ووزن الشحنة'),
      for (final w in WeightClass.values)
        SelectableTile(
          title: w.label,
          subtitle: w.range,
          icon: Icons.scale_outlined,
          selected: s.weight == w,
          onTap: () => c.setWeight(w),
        ),
      if (s.weight != null) ...[
        const SizedBox(height: 24),
        const _Title('نوع السيارة المطلوبة'),
        const Padding(
          padding: EdgeInsets.only(bottom: 8),
          child: Text('اقترحنا لك الأنسب حسب الوزن، ويمكنك تغييرها'),
        ),
        for (final v in VehicleType.values)
          SelectableTile(
            title: v.label,
            icon: switch (v) {
              VehicleType.pickup => Icons.airport_shuttle_outlined,
              VehicleType.jumbo => Icons.local_shipping_outlined,
              VehicleType.trailer => Icons.rv_hookup_outlined,
            },
            badge: v == s.weight!.recommendedVehicle ? 'مقترحة' : null,
            selected: s.vehicle == v,
            onTap: () => c.setVehicle(v),
          ),
      ],
    ]);
  }

  // ───────────── الخطوة 2: المسار والدبابيس ─────────────
  Widget _step1(BuildContext context, BookingState s, BookingCubit c) {
    Future<void> pick(String title, LatLng initial, ValueChanged<LatLng> onPicked) async {
      final p = await Navigator.push<LatLng>(
        context,
        MaterialPageRoute(builder: (_) => MapPickerScreen(title: title, initial: initial)),
      );
      if (p != null) onPicked(p);
    }

    final same = s.fromGov != null && s.fromGov == s.toGov;
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const _Title('موقع الانطلاق (التحميل)'),
      _GovDropdown(label: 'محافظة الانطلاق', value: s.fromGov, onChanged: c.setFromGov),
      const SizedBox(height: 10),
      OutlinedButton.icon(
        icon: const Icon(Icons.pin_drop_outlined),
        label: const Text('حدّد موقع التحميل بدقة على الخريطة'),
        onPressed: s.fromPin == null ? null : () => pick('موقع التحميل', s.fromPin!, c.setFromPin),
      ),
      const SizedBox(height: 28),
      const _Title('موقع الوصول (التسليم)'),
      _GovDropdown(label: 'محافظة الوصول', value: s.toGov, onChanged: c.setToGov),
      const SizedBox(height: 10),
      OutlinedButton.icon(
        icon: const Icon(Icons.flag_outlined),
        label: const Text('حدّد موقع التسليم بدقة على الخريطة'),
        onPressed: s.toPin == null ? null : () => pick('موقع التسليم', s.toPin!, c.setToPin),
      ),
      const SizedBox(height: 16),
      if (same)
        Text('اختر محافظتين مختلفتين للانطلاق والوصول',
            style: TextStyle(color: Theme.of(context).colorScheme.error))
      else if (s.fromPin != null && s.toPin != null)
        const Text('بعد اختيار المحافظة يوضع الدبوس في مركزها، حرّكه إلى العنوان الدقيق ليصل السائق بسهولة.'),
    ]);
  }

  // ───────────── الخطوة 3: التفاصيل ─────────────
  Widget _step2(BookingState s, BookingCubit c) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const _Title('تعليمات خاصة (اختياري)'),
      TextField(
        controller: _notes,
        maxLines: 4,
        onChanged: c.setNotes,
        decoration: const InputDecoration(hintText: 'مثال: البضاعة قابلة للكسر، التحميل من المخزن الخلفي...'),
      ),
      const SizedBox(height: 16),
      Card.outlined(
        child: SwitchListTile(
          secondary: const Icon(Icons.ac_unit),
          title: const Text('مطلوب براد / سيارة مغلقة'),
          subtitle: const Text('للمواد الغذائية أو البضائع الحساسة (تُضاف رسوم 20%)'),
          value: s.refrigerated,
          onChanged: c.setRefrigerated,
        ),
      ),
    ]);
  }

  // ───────────── الخطوة 4: السعر والدفع ─────────────
  Widget _step3(BookingState s, BookingCubit c) {
    final q = s.quote;
    if (q == null) return const SizedBox.shrink();
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Card.outlined(
        child: ListTile(
          leading: const Icon(Icons.route),
          title: Row(children: [
            Text(IraqData.nameOf(s.fromGov!), style: const TextStyle(fontWeight: FontWeight.bold)),
            const Padding(padding: EdgeInsets.symmetric(horizontal: 8), child: Icon(Icons.arrow_forward, size: 18)),
            Text(IraqData.nameOf(s.toGov!), style: const TextStyle(fontWeight: FontWeight.bold)),
          ]),
          subtitle: Text('${s.cargo!.label} · ${s.vehicle!.label}'),
        ),
      ),
      const SizedBox(height: 16),
      const _Title('تفصيل السعر'),
      PriceCard(quote: q),
      const SizedBox(height: 8),
      Card.outlined(
        child: Column(children: [
          SwitchListTile(
            secondary: const Icon(Icons.verified_user_outlined),
            title: const Text('تأمين البضاعة'),
            subtitle: const Text('اختياري، رسوم 1% من قيمة البضاعة المصرّح بها'),
            value: s.insured,
            onChanged: c.setInsured,
          ),
          if (s.insured)
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
              child: TextField(
                controller: _value,
                keyboardType: TextInputType.number,
                inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                onChanged: (v) => c.setDeclaredValue(double.tryParse(v) ?? 0),
                decoration: const InputDecoration(labelText: 'القيمة التقريبية للبضاعة (دينار عراقي)'),
              ),
            ),
        ]),
      ),
      const SizedBox(height: 24),
      const _Title('طريقة الدفع'),
      PaymentSelector(
        selected: s.payment,
        onChanged: c.setPayment,
        total: q.total,
        walletBalance: _wallet,
      ),
    ]);
  }
}

// ───────────────────────── عناصر مساعدة ─────────────────────────

class _Title extends StatelessWidget {
  const _Title(this.text);
  final String text;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: Text(text, style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
      );
}

class _StepHeader extends StatelessWidget {
  const _StepHeader({required this.step});
  final int step;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('الخطوة ${step + 1} من 4 · ${_stepTitles[step]}',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        ClipRRect(
          borderRadius: BorderRadius.circular(6),
          child: LinearProgressIndicator(value: (step + 1) / 4, minHeight: 8),
        ),
      ]),
    );
  }
}

class _GovDropdown extends StatelessWidget {
  const _GovDropdown({required this.label, required this.value, required this.onChanged});
  final String label;
  final String? value;
  final ValueChanged<String> onChanged;

  @override
  Widget build(BuildContext context) {
    return DropdownMenu<String>(
      label: Text(label),
      initialSelection: value,
      expandedInsets: EdgeInsets.zero, // يملأ عرض الشاشة
      menuHeight: 320,
      leadingIcon: const Icon(Icons.location_city),
      dropdownMenuEntries: [
        for (final g in IraqData.governorates) DropdownMenuEntry(value: g.id, label: g.nameAr),
      ],
      onSelected: (v) {
        if (v != null) onChanged(v);
      },
    );
  }
}

class _BottomBar extends StatelessWidget {
  const _BottomBar({
    required this.state,
    required this.disabledExtra,
    required this.onBack,
    required this.onNext,
    required this.onSubmit,
  });

  final BookingState state;
  final bool disabledExtra;
  final VoidCallback onBack, onNext, onSubmit;

  @override
  Widget build(BuildContext context) {
    final last = state.step == 3;
    final enabled = state.canContinue && !state.submitting && !(last && disabledExtra);
    return Material(
      elevation: 8,
      color: Theme.of(context).colorScheme.surface,
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(children: [
            if (state.step > 0) ...[
              Expanded(
                child: OutlinedButton(onPressed: state.submitting ? null : onBack, child: const Text('رجوع')),
              ),
              const SizedBox(width: 12),
            ],
            Expanded(
              flex: 2,
              child: FilledButton(
                onPressed: enabled ? (last ? onSubmit : onNext) : null,
                child: state.submitting
                    ? const SizedBox(height: 22, width: 22, child: CircularProgressIndicator(strokeWidth: 2))
                    : Text(last ? 'تأكيد الحجز · ${formatIqd(state.quote?.total ?? 0)}' : 'التالي'),
              ),
            ),
          ]),
        ),
      ),
    );
  }
}
