import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

/// شاشة تحديد موقع دقيق: الدبوس ثابت في المنتصف والخريطة تتحرك تحته.
/// تُرجع [LatLng] عند التأكيد.
class MapPickerScreen extends StatefulWidget {
  const MapPickerScreen({super.key, required this.title, required this.initial});
  final String title;
  final LatLng initial;

  @override
  State<MapPickerScreen> createState() => _MapPickerScreenState();
}

class _MapPickerScreenState extends State<MapPickerScreen> {
  late LatLng _center = widget.initial;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      body: Stack(
        children: [
          GoogleMap(
            initialCameraPosition: CameraPosition(target: widget.initial, zoom: 12),
            myLocationButtonEnabled: false,
            zoomControlsEnabled: false,
            onCameraMove: (p) => _center = p.target,
          ),
          // الدبوس: طرفه السفلي يقع على مركز الخريطة
          const IgnorePointer(
            child: Center(
              child: Padding(
                padding: EdgeInsets.only(bottom: 44),
                child: Icon(Icons.location_on, size: 48, color: Colors.red),
              ),
            ),
          ),
          Positioned(
            left: 16,
            right: 16,
            bottom: 24,
            child: FilledButton.icon(
              icon: const Icon(Icons.check),
              label: const Text('تأكيد هذا الموقع'),
              onPressed: () => Navigator.pop(context, _center),
            ),
          ),
        ],
      ),
    );
  }
}
