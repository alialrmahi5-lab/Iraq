import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:freight_core/freight_core.dart';
import 'package:intl/intl.dart';

import 'tracking/orders_cubit.dart';
import 'tracking/tracking_screen.dart';

/// سجل الطلبات: ثلاث تبويبات (نشطة / مكتملة / ملغاة) تتحدث لحظياً
class OrdersScreen extends StatelessWidget {
  const OrdersScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<OrdersCubit, OrdersState>(
      builder: (context, st) {
        return DefaultTabController(
          length: 3,
          child: Column(children: [
            TabBar(tabs: [
              Tab(text: 'نشطة (${st.active.length})'),
              Tab(text: 'مكتملة (${st.completed.length})'),
              Tab(text: 'ملغاة (${st.cancelled.length})'),
            ]),
            Expanded(
              child: st.loading
                  ? const Center(child: CircularProgressIndicator())
                  : TabBarView(children: [
                      _OrderList(
                        list: st.active,
                        emptyText: 'لا توجد شحنات نشطة\nاضغط «حجز شحنة جديدة» للبدء',
                      ),
                      _OrderList(list: st.completed, emptyText: 'لا توجد شحنات مكتملة بعد'),
                      _OrderList(list: st.cancelled, emptyText: 'لا توجد شحنات ملغاة'),
                    ]),
            ),
          ]),
        );
      },
    );
  }
}

class _OrderList extends StatelessWidget {
  const _OrderList({required this.list, required this.emptyText});
  final List<Shipment> list;
  final String emptyText;

  @override
  Widget build(BuildContext context) {
    if (list.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(Icons.inbox_outlined, size: 64, color: Theme.of(context).colorScheme.outline),
            const SizedBox(height: 12),
            Text(emptyText, textAlign: TextAlign.center, style: Theme.of(context).textTheme.bodyLarge),
          ]),
        ),
      );
    }
    return ListView.builder(
      // مساحة أسفل القائمة حتى لا يغطي زر الحجز آخر بطاقة
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 96),
      itemCount: list.length,
      itemBuilder: (_, i) => _OrderCard(shipment: list[i]),
    );
  }
}

Color _statusColor(ShipmentStatus s) => switch (s) {
      ShipmentStatus.open => Colors.orange,
      ShipmentStatus.delivered => Colors.green,
      ShipmentStatus.cancelled => Colors.grey,
      _ => Colors.blue,
    };

class _OrderCard extends StatelessWidget {
  const _OrderCard({required this.shipment});
  final Shipment shipment;

  @override
  Widget build(BuildContext context) {
    final s = shipment;
    final color = _statusColor(s.status);
    return Card.outlined(
      margin: const EdgeInsets.only(bottom: 10),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => TrackingScreen(shipment: s)),
        ),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Expanded(
                child: Row(children: [
                  Flexible(child: Text(s.fromName, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold))),
                  const Padding(padding: EdgeInsets.symmetric(horizontal: 8), child: Icon(Icons.arrow_forward, size: 18)),
                  Flexible(child: Text(s.toName, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold))),
                ]),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(color: color.withAlpha(36), borderRadius: BorderRadius.circular(20)),
                child: Text(s.status.label, style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.w600)),
              ),
            ]),
            const SizedBox(height: 6),
            Text('${s.cargo.label} · ${s.vehicle.label}'),
            if (s.driverName != null && s.status.isOngoing)
              Padding(
                padding: const EdgeInsets.only(top: 4),
                child: Row(children: [
                  const Icon(Icons.person_outline, size: 16),
                  const SizedBox(width: 4),
                  Text('السائق: ${s.driverName}'),
                ]),
              ),
            const SizedBox(height: 8),
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Text(DateFormat('yyyy/MM/dd  HH:mm', 'en').format(s.createdAt.toLocal()),
                  style: TextStyle(color: Theme.of(context).colorScheme.outline, fontSize: 12)),
              Text(formatIqd(s.total), style: const TextStyle(fontWeight: FontWeight.bold)),
            ]),
            if (s.status.isOngoing)
              const Padding(
                padding: EdgeInsets.only(top: 8),
                child: Row(children: [
                  Icon(Icons.map_outlined, size: 16),
                  SizedBox(width: 4),
                  Text('اضغط لعرض التتبع الحي على الخريطة', style: TextStyle(fontSize: 12)),
                ]),
              ),
          ]),
        ),
      ),
    );
  }
}
