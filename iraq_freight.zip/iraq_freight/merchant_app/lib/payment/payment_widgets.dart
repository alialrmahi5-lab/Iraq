import 'package:flutter/material.dart';
import 'package:freight_core/freight_core.dart';

IconData paymentIcon(PaymentMethod m) => switch (m) {
      PaymentMethod.zainCash => Icons.phone_android,
      PaymentMethod.asiaHawala => Icons.currency_exchange,
      PaymentMethod.card => Icons.credit_card,
      PaymentMethod.cashOnPickup => Icons.payments_outlined,
      PaymentMethod.cashOnDelivery => Icons.local_atm,
      PaymentMethod.wallet => Icons.account_balance_wallet_outlined,
    };

/// بطاقة اختيار كبيرة وواضحة (تُستخدم للبضاعة، السيارة، طرق الدفع)
class SelectableTile extends StatelessWidget {
  const SelectableTile({
    super.key,
    required this.title,
    required this.icon,
    required this.selected,
    required this.onTap,
    this.subtitle,
    this.subtitleColor,
    this.badge,
  });

  final String title;
  final String? subtitle;
  final String? badge;
  final Color? subtitleColor;
  final IconData icon;
  final bool selected;

  /// null = معطّلة
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Opacity(
        opacity: onTap == null ? 0.5 : 1,
        child: InkWell(
          borderRadius: BorderRadius.circular(14),
          onTap: onTap,
          child: Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: selected ? cs.primaryContainer : null,
              border: Border.all(color: selected ? cs.primary : cs.outlineVariant, width: selected ? 2 : 1),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Row(children: [
              Icon(icon, color: cs.primary, size: 28),
              const SizedBox(width: 12),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    Flexible(child: Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600))),
                    if (badge != null) ...[
                      const SizedBox(width: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                        decoration: BoxDecoration(color: cs.primary, borderRadius: BorderRadius.circular(8)),
                        child: Text(badge!, style: TextStyle(color: cs.onPrimary, fontSize: 11)),
                      ),
                    ],
                  ]),
                  if (subtitle != null)
                    Text(subtitle!, style: TextStyle(fontSize: 13, color: subtitleColor ?? cs.onSurfaceVariant)),
                ]),
              ),
              if (selected) Icon(Icons.check_circle, color: cs.primary),
            ]),
          ),
        ),
      ),
    );
  }
}

/// قائمة طرق الدفع: زين كاش، آسيا حوالة، بطاقة، نقداً، والمحفظة الداخلية
class PaymentSelector extends StatelessWidget {
  const PaymentSelector({
    super.key,
    required this.selected,
    required this.onChanged,
    required this.total,
    required this.walletBalance,
  });

  final PaymentMethod selected;
  final ValueChanged<PaymentMethod> onChanged;
  final double total;

  /// null = لم يُحمَّل الرصيد بعد
  final double? walletBalance;

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      for (final m in PaymentMethod.values) _tile(context, m),
    ]);
  }

  Widget _tile(BuildContext context, PaymentMethod m) {
    if (m != PaymentMethod.wallet) {
      return SelectableTile(
        title: m.label,
        icon: paymentIcon(m),
        selected: selected == m,
        onTap: () => onChanged(m),
      );
    }
    final bal = walletBalance;
    final enough = bal != null && bal >= total;
    return SelectableTile(
      title: m.label,
      icon: paymentIcon(m),
      selected: selected == m,
      subtitle: bal == null
          ? 'جارٍ تحميل الرصيد...'
          : enough
              ? 'الرصيد: ${formatIqd(bal)}'
              : 'الرصيد ${formatIqd(bal)} غير كافٍ، اشحن المحفظة أولاً',
      subtitleColor: (bal != null && !enough) ? Theme.of(context).colorScheme.error : null,
      onTap: enough ? () => onChanged(m) : null,
    );
  }
}

/// تفصيل السعر: أجرة أساسية + أجرة مسافة + رسوم اختيارية
class PriceCard extends StatelessWidget {
  const PriceCard({super.key, required this.quote});
  final PriceQuote quote;

  @override
  Widget build(BuildContext context) {
    return Card.outlined(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(children: [
          _row('المسافة التقريبية', '${quote.distanceKm.round()} كم'),
          _row('أجرة الشحن الأساسية', formatIqd(quote.baseFare)),
          _row('أجرة المسافة', formatIqd(quote.distanceFare)),
          if (quote.refrigerationFee > 0) _row('رسوم البراد / السيارة المغلقة', formatIqd(quote.refrigerationFee)),
          if (quote.insuranceFee > 0) _row('رسوم تأمين البضاعة (1%)', formatIqd(quote.insuranceFee)),
          const Divider(height: 24),
          _row('الإجمالي', formatIqd(quote.total), strong: true),
        ]),
      ),
    );
  }

  Widget _row(String label, String value, {bool strong = false}) {
    final style = TextStyle(fontSize: strong ? 20 : 15, fontWeight: strong ? FontWeight.bold : FontWeight.normal);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [Text(label, style: style), Text(value, style: style)],
      ),
    );
  }
}
