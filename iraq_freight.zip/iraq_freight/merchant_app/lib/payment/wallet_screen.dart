import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:freight_core/freight_core.dart';

import 'payment_widgets.dart';

/// المحفظة الإلكترونية داخل التطبيق (نسخة تجريبية Dummy Wallet).
///
/// ⚠️ شحن الرصيد هنا يحاكي الدفع. قبل الإطلاق الفعلي يجب أن يتم الشحن من الخادم
/// فقط بعد تأكيد الدفع من بوابة (زين كاش / آسيا حوالة / كي كارد) عبر Webhook،
/// وليس بنداء مباشر من التطبيق كما في هذه النسخة.
class WalletScreen extends StatefulWidget {
  const WalletScreen({super.key, required this.user});
  final AppUser user;

  @override
  State<WalletScreen> createState() => _WalletScreenState();
}

class _WalletScreenState extends State<WalletScreen> {
  static const _quick = [25000.0, 50000.0, 100000.0, 250000.0, 500000.0];
  static const _sources = [PaymentMethod.zainCash, PaymentMethod.asiaHawala, PaymentMethod.card];

  final _custom = TextEditingController();
  double? _balance;
  double _amount = 50000;
  PaymentMethod _source = PaymentMethod.zainCash;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _custom.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final b = await context.read<FreightRepository>().walletBalance(widget.user.id);
      if (mounted) setState(() => _balance = b);
    } catch (_) {
      if (mounted) setState(() => _balance = 0);
    }
  }

  void _msg(String t) => ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(t)));

  Future<void> _topUp() async {
    if (_amount < 5000) {
      _msg('أقل مبلغ للشحن 5,000 د.ع');
      return;
    }
    setState(() => _busy = true);
    try {
      final b = await context.read<FreightRepository>().topUpWallet(widget.user.id, _amount);
      if (!mounted) return;
      setState(() => _balance = b);
      _msg('تم شحن ${formatIqd(_amount)} بنجاح');
    } on FreightException catch (e) {
      if (mounted) _msg(e.message);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(color: cs.primary, borderRadius: BorderRadius.circular(20)),
          child: Column(children: [
            Text('رصيدك الحالي', style: TextStyle(color: cs.onPrimary.withAlpha(200))),
            const SizedBox(height: 8),
            _balance == null
                ? SizedBox(height: 36, width: 36, child: CircularProgressIndicator(color: cs.onPrimary))
                : Text(formatIqd(_balance!),
                    style: TextStyle(color: cs.onPrimary, fontSize: 32, fontWeight: FontWeight.bold)),
          ]),
        ),
        const SizedBox(height: 24),
        Text('شحن المحفظة', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        Wrap(spacing: 8, runSpacing: 8, children: [
          for (final v in _quick)
            ChoiceChip(
              label: Text(formatIqd(v)),
              selected: _amount == v && _custom.text.isEmpty,
              onSelected: (_) => setState(() {
                _custom.clear();
                _amount = v;
              }),
            ),
        ]),
        const SizedBox(height: 12),
        TextField(
          controller: _custom,
          keyboardType: TextInputType.number,
          inputFormatters: [FilteringTextInputFormatter.digitsOnly],
          onChanged: (v) => setState(() => _amount = double.tryParse(v) ?? 0),
          decoration: const InputDecoration(labelText: 'أو أدخل مبلغاً آخر (دينار عراقي)'),
        ),
        const SizedBox(height: 20),
        Text('الشحن عن طريق', style: Theme.of(context).textTheme.titleSmall),
        const SizedBox(height: 8),
        for (final m in _sources)
          SelectableTile(
            title: m.label,
            icon: paymentIcon(m),
            selected: _source == m,
            onTap: () => setState(() => _source = m),
          ),
        const SizedBox(height: 8),
        FilledButton(
          onPressed: _busy || _amount <= 0 ? null : _topUp,
          child: _busy
              ? const SizedBox(height: 22, width: 22, child: CircularProgressIndicator(strokeWidth: 2))
              : Text('شحن ${formatIqd(_amount)}'),
        ),
        const SizedBox(height: 12),
        Text(
          'نسخة تجريبية: الشحن هنا محاكاة ولا يتم سحب أي مبلغ فعلي.',
          textAlign: TextAlign.center,
          style: TextStyle(color: cs.outline, fontSize: 12),
        ),
      ],
    );
  }
}
