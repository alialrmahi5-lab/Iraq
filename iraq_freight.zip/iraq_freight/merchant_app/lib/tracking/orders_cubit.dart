import 'dart:async';

import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:freight_core/freight_core.dart';

class OrdersState extends Equatable {
  const OrdersState({this.all = const [], this.loading = true, this.error});
  final List<Shipment> all;
  final bool loading;
  final String? error;

  List<Shipment> get active => all.where((s) => s.status.isActive).toList();
  List<Shipment> get completed => all.where((s) => s.status == ShipmentStatus.delivered).toList();
  List<Shipment> get cancelled => all.where((s) => s.status == ShipmentStatus.cancelled).toList();

  @override
  List<Object?> get props => [all, loading, error];
}

/// يشترك بتيار شحنات التاجر ويحدّث القوائم الثلاث (نشطة / مكتملة / ملغاة) لحظياً
class OrdersCubit extends Cubit<OrdersState> {
  OrdersCubit(FreightRepository repo, String merchantId) : super(const OrdersState()) {
    _sub = repo.watchMerchantShipments(merchantId).listen(
          (list) => emit(OrdersState(all: list, loading: false)),
          onError: (_) => emit(OrdersState(all: state.all, loading: false, error: 'تعذّر تحميل الشحنات، تحقق من الاتصال')),
        );
  }

  late final StreamSubscription<List<Shipment>> _sub;

  @override
  Future<void> close() {
    _sub.cancel();
    return super.close();
  }
}
