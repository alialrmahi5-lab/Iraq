import 'dart:async';

import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:freight_core/freight_core.dart';

class TrackingState extends Equatable {
  const TrackingState({required this.shipment, this.cancelling = false});
  final Shipment shipment;
  final bool cancelling;

  @override
  List<Object?> get props => [shipment, cancelling];
}

/// التتبع الحي: يستقبل كل تحديث للشحنة (الحالة + إحداثيات السائق) عبر Stream
/// (Supabase Realtime في الإنتاج) ويدفعه إلى الواجهة.
class TrackingCubit extends Cubit<TrackingState> {
  TrackingCubit(this._repo, Shipment initial) : super(TrackingState(shipment: initial)) {
    _sub = _repo.watchShipment(initial.id).listen(
          (s) => emit(TrackingState(shipment: s)),
          onError: (_) {}, // نُبقي آخر حالة معروفة عند انقطاع الاتصال
        );
  }

  final FreightRepository _repo;
  late final StreamSubscription<Shipment> _sub;

  /// الإلغاء مسموح قبل أن يقبل سائق الطلب فقط
  bool get canCancel => state.shipment.status == ShipmentStatus.open;

  Future<void> cancel() async {
    if (!canCancel) return;
    emit(TrackingState(shipment: state.shipment, cancelling: true));
    try {
      await _repo.cancelShipment(state.shipment.id);
    } finally {
      if (!isClosed) emit(TrackingState(shipment: state.shipment));
    }
  }

  @override
  Future<void> close() {
    _sub.cancel();
    return super.close();
  }
}
