import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:freight_core/freight_core.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

import 'tracking_cubit.dart';

/// تتبع شحنة على خريطة جوجل مع موقع السائق الحي وحالة الطلب
class TrackingScreen extends StatelessWidget {
  const TrackingScreen({super.key, required this.shipment});
  final Shipment shipment;

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (ctx) => TrackingCubit(ctx.read<FreightRepository>(), shipment),
      child: const _TrackingView(),
    );
  }
}

class _TrackingView extends StatefulWidget {
  const _TrackingView();

  @override
  State<_TrackingView> createState() => _TrackingViewState();
}

class _TrackingViewState extends State<_TrackingView> {
  GoogleMapController? _map;
  bool _follow = true;

  @override
  void dispose() {
    _map?.dispose();
    super.dispose();
  }

  LatLng _mid(Shipment s) => LatLng((s.fromLat + s.toLat) / 2, (s.fromLng + s.toLng) / 2);

  /// يعرض المسار كاملاً داخل الشاشة
  void _fitRoute(Shipment s) {
    final dLat = (s.fromLat - s.toLat).abs(), dLng = (s.fromLng - s.toLng).abs();
    if (dLat < 0.002 && dLng < 0.002) {
      _map?.animateCamera(CameraUpdate.newLatLngZoom(LatLng(s.fromLat, s.fromLng), 13));
      return;
    }
    final bounds = LatLngBounds(
      southwest: LatLng(math.min(s.fromLat, s.toLat), math.min(s.fromLng, s.toLng)),
      northeast: LatLng(math.max(s.fromLat, s.toLat), math.max(s.fromLng, s.toLng)),
    );
    _map?.animateCamera(CameraUpdate.newLatLngBounds(bounds, 64));
  }

  Set<Marker> _markers(Shipment s) => {
        Marker(
          markerId: const MarkerId('from'),
          position: LatLng(s.fromLat, s.fromLng),
          icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueGreen),
          infoWindow: InfoWindow(title: 'موقع التحميل', snippet: s.fromName),
        ),
        Marker(
          markerId: const MarkerId('to'),
          position: LatLng(s.toLat, s.toLng),
          icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueRed),
          infoWindow: InfoWindow(title: 'موقع التسليم', snippet: s.toName),
        ),
        if (s.driverLat != null && s.driverLng != null)
          Marker(
            markerId: const MarkerId('driver'),
            position: LatLng(s.driverLat!, s.driverLng!),
            icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueAzure),
            infoWindow: InfoWindow(title: 'السائق', snippet: s.driverName),
            zIndex: 2.0,
          ),
      };

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final first = context.read<TrackingCubit>().state.shipment;

    return BlocListener<TrackingCubit, TrackingState>(
      // كل تحرك للسائق يحرّك الكاميرا خلفه (إن كان التتبع التلقائي مفعّلاً)
      listenWhen: (a, b) =>
          a.shipment.driverLat != b.shipment.driverLat || a.shipment.driverLng != b.shipment.driverLng,
      listener: (context, st) {
        final s = st.shipment;
        if (_follow && s.driverLat != null && s.driverLng != null) {
          _map?.animateCamera(CameraUpdate.newLatLng(LatLng(s.driverLat!, s.driverLng!)));
        }
      },
      child: Scaffold(
        appBar: AppBar(
          title: Text('${first.fromName} ← ${first.toName}'),
          actions: const [ThemeToggleButton()],
        ),
        body: BlocBuilder<TrackingCubit, TrackingState>(
          builder: (context, st) {
            final s = st.shipment;
            return Column(children: [
              Expanded(
                child: Stack(children: [
                  GoogleMap(
                    initialCameraPosition: CameraPosition(target: _mid(first), zoom: 7),
                    markers: _markers(s),
                    polylines: {
                      Polyline(
                        polylineId: const PolylineId('route'),
                        points: [LatLng(s.fromLat, s.fromLng), LatLng(s.toLat, s.toLng)],
                        color: cs.primary,
                        width: 4,
                        patterns: [PatternItem.dash(18), PatternItem.gap(10)],
                      ),
                    },
                    zoomControlsEnabled: false,
                    myLocationButtonEnabled: false,
                    onMapCreated: (c) {
                      _map = c;
                      Future.delayed(const Duration(milliseconds: 400), () => _fitRoute(first));
                    },
                  ),
                  Positioned(
                    top: 12,
                    left: 12,
                    child: Column(children: [
                      FloatingActionButton.small(
                        heroTag: 'fit',
                        tooltip: 'عرض المسار كاملاً',
                        onPressed: () {
                          setState(() => _follow = false);
                          _fitRoute(s);
                        },
                        child: const Icon(Icons.zoom_out_map),
                      ),
                      const SizedBox(height: 8),
                      if (s.driverLat != null)
                        FloatingActionButton.small(
                          heroTag: 'follow',
                          tooltip: 'تتبع السائق',
                          backgroundColor: _follow ? cs.primary : null,
                          foregroundColor: _follow ? cs.onPrimary : null,
                          onPressed: () {
                            setState(() => _follow = !_follow);
                            if (_follow) {
                              _map?.animateCamera(CameraUpdate.newLatLng(LatLng(s.driverLat!, s.driverLng!)));
                            }
                          },
                          child: const Icon(Icons.my_location),
                        ),
                    ]),
                  ),
                ]),
              ),
              ConstrainedBox(
                constraints: BoxConstraints(maxHeight: MediaQuery.sizeOf(context).height * 0.44),
                child: _StatusPanel(state: st),
              ),
            ]);
          },
        ),
      ),
    );
  }
}

// ───────────────────────── لوحة الحالة ─────────────────────────

const _steps = [
  (ShipmentStatus.accepted, 'قُبل الطلب'),
  (ShipmentStatus.atPickup, 'التحميل'),
  (ShipmentStatus.inTransit, 'في الطريق'),
  (ShipmentStatus.atDropoff, 'التسليم'),
  (ShipmentStatus.delivered, 'تم'),
];

class _StatusPanel extends StatelessWidget {
  const _StatusPanel({required this.state});
  final TrackingState state;

  @override
  Widget build(BuildContext context) {
    final s = state.shipment;
    final cs = Theme.of(context).colorScheme;
    return Material(
      elevation: 8,
      color: cs.surface,
      child: SafeArea(
        top: false,
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(s.status.label, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            if (s.status == ShipmentStatus.open) ...[
              const LinearProgressIndicator(),
              const SizedBox(height: 8),
              const Text('نبحث لك عن أقرب سائق مناسب لنوع سيارتك...'),
            ] else if (s.status == ShipmentStatus.cancelled)
              const Text('تم إلغاء هذه الشحنة')
            else
              _Stepper(status: s.status),
            if (s.driverName != null && s.status.isOngoing) ...[
              const Divider(height: 28),
              Row(children: [
                const CircleAvatar(child: Icon(Icons.person)),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(s.driverName!, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
                    Text(s.vehicle.label),
                  ]),
                ),
                if (s.driverPhone != null) ...[
                  IconButton.filledTonal(
                    tooltip: 'اتصال',
                    icon: const Icon(Icons.call),
                    onPressed: () => callPhone(s.driverPhone!),
                  ),
                  const SizedBox(width: 4),
                  IconButton.filledTonal(
                    tooltip: 'واتساب',
                    icon: const Icon(Icons.chat),
                    onPressed: () => openWhatsApp(s.driverPhone!, text: 'السلام عليكم، بخصوص شحنة ${s.fromName} ← ${s.toName}'),
                  ),
                ],
              ]),
            ],
            const Divider(height: 28),
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Text('${s.distanceKm.round()} كم · ${s.paymentMethod.label}'),
              Text(formatIqd(s.total), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            ]),
            if (s.status == ShipmentStatus.delivered && s.proofPath != null) ...[
              const SizedBox(height: 8),
              Row(children: [
                Icon(Icons.verified, color: cs.primary, size: 20),
                const SizedBox(width: 6),
                const Text('تم رفع وصل التسليم الموقّع من المستلم'),
              ]),
            ],
            if (s.status == ShipmentStatus.open) ...[
              const SizedBox(height: 12),
              OutlinedButton.icon(
                icon: state.cancelling
                    ? const SizedBox(height: 18, width: 18, child: CircularProgressIndicator(strokeWidth: 2))
                    : const Icon(Icons.close),
                label: const Text('إلغاء الطلب'),
                onPressed: state.cancelling ? null : () => _confirmCancel(context),
              ),
            ],
          ]),
        ),
      ),
    );
  }

  Future<void> _confirmCancel(BuildContext context) async {
    final cubit = context.read<TrackingCubit>();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('إلغاء الطلب؟'),
        content: const Text('سيتم إلغاء الشحنة ولن يتمكن أي سائق من قبولها.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('تراجع')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('نعم، إلغاء')),
        ],
      ),
    );
    if (ok == true) cubit.cancel();
  }
}

/// شريط مراحل الشحنة: قُبل ← التحميل ← في الطريق ← التسليم ← تم
class _Stepper extends StatelessWidget {
  const _Stepper({required this.status});
  final ShipmentStatus status;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final current = _steps.indexWhere((e) => e.$1 == status);
    return Row(children: [
      for (var i = 0; i < _steps.length; i++)
        Expanded(
          child: Column(children: [
            Row(children: [
              Expanded(child: Container(height: 3, color: i == 0 ? Colors.transparent : (i <= current ? cs.primary : cs.outlineVariant))),
              CircleAvatar(
                radius: 11,
                backgroundColor: i <= current ? cs.primary : cs.outlineVariant,
                child: i <= current ? Icon(Icons.check, size: 14, color: cs.onPrimary) : null,
              ),
              Expanded(child: Container(height: 3, color: i == _steps.length - 1 ? Colors.transparent : (i < current ? cs.primary : cs.outlineVariant))),
            ]),
            const SizedBox(height: 6),
            Text(_steps[i].$2,
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 11, fontWeight: i == current ? FontWeight.bold : FontWeight.normal)),
          ]),
        ),
    ]);
  }
}
