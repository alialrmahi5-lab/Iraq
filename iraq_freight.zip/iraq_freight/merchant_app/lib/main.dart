import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:freight_core/freight_core.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'home_screen.dart';
import 'profile_screen.dart';

Future<void> main() async {
  final repo = await bootstrapBackend(UserRole.merchant);
  final prefs = await SharedPreferences.getInstance();
  runApp(MerchantApp(repo: repo, prefs: prefs));
}

class MerchantApp extends StatelessWidget {
  const MerchantApp({super.key, required this.repo, required this.prefs});
  final FreightRepository repo;
  final SharedPreferences prefs;

  @override
  Widget build(BuildContext context) {
    return RepositoryProvider<FreightRepository>.value(
      value: repo,
      child: MultiBlocProvider(
        providers: [
          BlocProvider(create: (_) => ThemeCubit(prefs)),
          BlocProvider(create: (_) => AuthCubit(repo)..start()),
        ],
        child: BlocBuilder<ThemeCubit, ThemeMode>(
          builder: (context, mode) => MaterialApp(
            title: 'شحن العراق - التاجر',
            debugShowCheckedModeBanner: false,
            // العربية هي اللغة الأساسية، والاتجاه RTL تلقائي
            locale: const Locale('ar'),
            supportedLocales: const [Locale('ar')],
            localizationsDelegates: const [
              GlobalMaterialLocalizations.delegate,
              GlobalWidgetsLocalizations.delegate,
              GlobalCupertinoLocalizations.delegate,
            ],
            theme: AppTheme.light,
            darkTheme: AppTheme.dark,
            themeMode: mode,
            home: AuthGate(
              appTitle: 'شحن العراق',
              subtitle: 'احجز سيارة حمل لبضاعتك بين المحافظات بضغطة واحدة',
              icon: Icons.local_shipping_rounded,
              profileBuilder: (_, user) => MerchantProfileScreen(user: user),
              homeBuilder: (_, user) => HomeScreen(user: user),
            ),
          ),
        ),
      ),
    );
  }
}
