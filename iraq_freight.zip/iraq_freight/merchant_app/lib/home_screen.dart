import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:freight_core/freight_core.dart';

import 'booking/booking_screen.dart';
import 'orders_screen.dart';
import 'payment/wallet_screen.dart';
import 'tracking/orders_cubit.dart';
import 'tracking/tracking_screen.dart';

/// الشاشة الرئيسية للتاجر: «شحناتي» (نشطة/مكتملة/ملغاة) و«المحفظة»
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key, required this.user});
  final AppUser user;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _tab = 0;

  /// يفتح استمارة الحجز، وعند نجاحها ينتقل مباشرة لتتبع الشحنة الجديدة
  Future<void> _book() async {
    final created = await Navigator.push<Shipment>(
      context,
      MaterialPageRoute(builder: (_) => BookingScreen(user: widget.user)),
    );
    if (created != null && mounted) {
      Navigator.push(context, MaterialPageRoute(builder: (_) => TrackingScreen(shipment: created)));
    }
  }

  Future<void> _logout() async {
    final auth = context.read<AuthCubit>();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('تسجيل الخروج'),
        content: const Text('هل تريد تسجيل الخروج من حسابك؟'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('خروج')),
        ],
      ),
    );
    if (ok == true) auth.signOut();
  }

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (ctx) => OrdersCubit(ctx.read<FreightRepository>(), widget.user.id),
      child: Scaffold(
        appBar: AppBar(
          title: Text(_tab == 0 ? 'شحناتي' : 'المحفظة'),
          actions: [
            const ThemeToggleButton(),
            IconButton(tooltip: 'تسجيل الخروج', icon: const Icon(Icons.logout), onPressed: _logout),
          ],
        ),
        // تُعاد بناء المحفظة عند كل فتح لتحديث الرصيد بعد الدفع منها
        body: _tab == 0 ? const OrdersScreen() : WalletScreen(user: widget.user),
        floatingActionButton: _tab == 0
            ? FloatingActionButton.extended(
                onPressed: _book,
                icon: const Icon(Icons.add),
                label: const Text('حجز شحنة جديدة'),
              )
            : null,
        bottomNavigationBar: NavigationBar(
          selectedIndex: _tab,
          onDestinationSelected: (i) => setState(() => _tab = i),
          destinations: const [
            NavigationDestination(
              icon: Icon(Icons.local_shipping_outlined),
              selectedIcon: Icon(Icons.local_shipping),
              label: 'شحناتي',
            ),
            NavigationDestination(
              icon: Icon(Icons.account_balance_wallet_outlined),
              selectedIcon: Icon(Icons.account_balance_wallet),
              label: 'المحفظة',
            ),
          ],
        ),
      ),
    );
  }
}
