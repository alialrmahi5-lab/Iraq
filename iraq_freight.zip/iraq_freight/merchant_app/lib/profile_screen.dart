import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:freight_core/freight_core.dart';

/// إعداد الملف الشخصي للتاجر: الاسم + نوع الحساب (شركة/معمل أو تاجر جملة فردي)
class MerchantProfileScreen extends StatefulWidget {
  const MerchantProfileScreen({super.key, required this.user});
  final AppUser user;

  @override
  State<MerchantProfileScreen> createState() => _MerchantProfileScreenState();
}

class _MerchantProfileScreenState extends State<MerchantProfileScreen> {
  final _name = TextEditingController();
  AccountType? _type;

  @override
  void dispose() {
    _name.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final busy = context.watch<AuthCubit>().state.busy;
    final canSave = _name.text.trim().length >= 3 && _type != null;
    return Scaffold(
      appBar: AppBar(title: const Text('إعداد الحساب'), actions: const [ThemeToggleButton()]),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Text('أهلاً بك 👋', style: Theme.of(context).textTheme.headlineSmall),
          const SizedBox(height: 4),
          const Text('أخبرنا قليلاً عنك لنجهّز حسابك'),
          const SizedBox(height: 24),
          TextField(
            controller: _name,
            onChanged: (_) => setState(() {}),
            decoration: const InputDecoration(labelText: 'الاسم أو اسم الشركة', prefixIcon: Icon(Icons.badge_outlined)),
          ),
          const SizedBox(height: 24),
          Text('نوع الحساب', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 12),
          for (final t in AccountType.values)
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: _TypeCard(
                label: t.label,
                icon: t == AccountType.company ? Icons.factory_outlined : Icons.storefront_outlined,
                selected: _type == t,
                onTap: () => setState(() => _type = t),
              ),
            ),
          const SizedBox(height: 12),
          FilledButton(
            onPressed: canSave && !busy
                ? () => context
                    .read<AuthCubit>()
                    .completeProfile(widget.user.copyWith(fullName: _name.text.trim(), accountType: _type))
                : null,
            child: busy
                ? const SizedBox(height: 22, width: 22, child: CircularProgressIndicator(strokeWidth: 2))
                : const Text('حفظ والمتابعة'),
          ),
        ],
      ),
    );
  }
}

class _TypeCard extends StatelessWidget {
  const _TypeCard({required this.label, required this.icon, required this.selected, required this.onTap});
  final String label;
  final IconData icon;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          color: selected ? cs.primaryContainer : null,
          border: Border.all(color: selected ? cs.primary : cs.outlineVariant, width: selected ? 2 : 1),
          borderRadius: BorderRadius.circular(16),
        ),
        child: Row(children: [
          Icon(icon, size: 30, color: cs.primary),
          const SizedBox(width: 14),
          Expanded(child: Text(label, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600))),
          if (selected) Icon(Icons.check_circle, color: cs.primary),
        ]),
      ),
    );
  }
}
