import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

/// زر «اسحب للقبول»: يمنع القبول بنقرة خاطئة أثناء القيادة.
/// يبدأ المقبض من بداية السطر (اليمين في العربية) ويُسحب نحو النهاية (اليسار).
class SlideToAcceptButton extends StatefulWidget {
  const SlideToAcceptButton({
    super.key,
    required this.label,
    required this.onAccepted,
    this.busy = false,
    this.height = 68,
  });

  final String label;
  final VoidCallback onAccepted;

  /// أثناء الانتظار من الخادم: يظهر مؤشر تحميل ويُعطَّل السحب
  final bool busy;
  final double height;

  @override
  State<SlideToAcceptButton> createState() => _SlideToAcceptButtonState();
}

class _SlideToAcceptButtonState extends State<SlideToAcceptButton> {
  double _dx = 0; // إزاحة المقبض من البداية بالبكسل
  bool _dragging = false;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final rtl = Directionality.of(context) == TextDirection.rtl;
    final thumb = widget.height - 10;

    return LayoutBuilder(builder: (context, box) {
      final maxDx = box.maxWidth - thumb - 10;
      final progress = maxDx <= 0 ? 0.0 : (_dx / maxDx).clamp(0.0, 1.0);

      void end() {
        if (widget.busy) return;
        if (progress >= 0.85) {
          HapticFeedback.heavyImpact();
          widget.onAccepted();
        }
        setState(() {
          _dragging = false;
          _dx = 0; // يرجع المقبض دائماً؛ الواجهة تتحول لحالة التحميل
        });
      }

      return Container(
        height: widget.height,
        decoration: BoxDecoration(
          color: Color.lerp(cs.primaryContainer, cs.primary, progress),
          borderRadius: BorderRadius.circular(widget.height / 2),
        ),
        child: Stack(alignment: Alignment.center, children: [
          // النص يتلاشى كلما سُحب المقبض
          Opacity(
            opacity: widget.busy ? 1 : (1 - progress),
            child: widget.busy
                ? SizedBox(
                    height: 28,
                    width: 28,
                    child: CircularProgressIndicator(strokeWidth: 3, color: cs.onPrimaryContainer),
                  )
                : Padding(
                    padding: EdgeInsetsDirectional.only(start: thumb + 8, end: 16),
                    child: Row(mainAxisSize: MainAxisSize.min, children: [
                      Flexible(
                        child: Text(
                          widget.label,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: cs.onPrimaryContainer),
                        ),
                      ),
                      const SizedBox(width: 6),
                      Icon(Icons.keyboard_double_arrow_left, color: cs.onPrimaryContainer),
                    ]),
                  ),
          ),
          AnimatedPositionedDirectional(
            duration: _dragging ? Duration.zero : const Duration(milliseconds: 200),
            start: 5 + _dx,
            top: 5,
            child: GestureDetector(
              onHorizontalDragStart: widget.busy ? null : (_) => setState(() => _dragging = true),
              onHorizontalDragUpdate: widget.busy
                  ? null
                  : (d) => setState(() {
                        // في RTL يكون اتجاه السحب نحو اليسار (dx سالب) هو التقدّم
                        final delta = rtl ? -d.delta.dx : d.delta.dx;
                        _dx = (_dx + delta).clamp(0.0, maxDx);
                      }),
              onHorizontalDragEnd: (_) => end(),
              onHorizontalDragCancel: end,
              child: Container(
                width: thumb,
                height: thumb,
                decoration: BoxDecoration(color: cs.surface, shape: BoxShape.circle),
                child: Icon(Icons.local_shipping, color: cs.primary, size: 30),
              ),
            ),
          ),
        ]),
      );
    });
  }
}
