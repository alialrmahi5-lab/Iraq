import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:freight_core/freight_core.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'register/driver_profile_screen.dart';
import 'register/verification_gate.dart';

Future<void> main() async {
  final repo = await bootstrapBackend(UserRole.driver);
  final prefs = await SharedPreferences.getInstance();
  runApp(DriverApp(repo: repo, prefs: prefs));
}

class DriverApp extends StatelessWidget {
  const DriverApp({super.key, required this.repo, required this.prefs});
  final FreightRepository repo;
  final SharedPreferences prefs;

  // لون برتقالي ليتميّز تطبيق السائق عن تطبيق التاجر الأخضر
  static const _seed = Color(0xFFE65100);

  @override
  Widget build(BuildContext context) {
    return RepositoryProvider<FreightRepository>.value(
      value: repo,
      child: MultiBlocProvider(
        providers: [
          BlocProvider(create: (_) => ThemeCubit(prefs)),
          BlocProvider(create: (_) => AuthCubit(repo)..start()),
        ],
        child: BlocBuilder<ThemeCubit, ThemeMode>(
          builder: (context, mode) => MaterialApp(
            title: 'شحن العراق - السائق',
            debugShowCheckedModeBanner: false,
            locale: const Locale('ar'),
            supportedLocales: const [Locale('ar')],
            localizationsDelegates: const [
              GlobalMaterialLocalizations.delegate,
              GlobalWidgetsLocalizations.delegate,
              GlobalCupertinoLocalizations.delegate,
            ],
            theme: AppTheme.build(Brightness.light, seed: _seed),
            darkTheme: AppTheme.build(Brightness.dark, seed: _seed),
            themeMode: mode,
            // خط أكبر قليلاً لسهولة القراءة أثناء القيادة
            builder: (context, child) {
              final mq = MediaQuery.of(context);
              final scale = mq.textScaler.scale(1.0) < 1.1 ? const TextScaler.linear(1.1) : mq.textScaler;
              return MediaQuery(data: mq.copyWith(textScaler: scale), child: child!);
            },
            home: AuthGate(
              appTitle: 'شحن العراق · السائق',
              subtitle: 'استقبل طلبات الشحن واربح من كل رحلة، ذهاباً وإياباً',
              icon: Icons.local_shipping_rounded,
              profileBuilder: (_, user) => DriverProfileScreen(user: user),
              homeBuilder: (_, user) => VerificationGate(user: user),
            ),
          ),
        ),
      ),
    );
  }
}
