import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:freight_core/freight_core.dart';
import 'package:image_picker/image_picker.dart';

/// رفع وثائق التدقيق الأمني: إجازة السوق، سنوية السيارة، البطاقة الوطنية الموحدة
class DocumentsScreen extends StatefulWidget {
  const DocumentsScreen({super.key, required this.user, required this.onSubmitted, this.rejected = false});
  final AppUser user;
  final VoidCallback onSubmitted;

  /// true إن رُفضت الوثائق السابقة ويُطلب إعادة رفعها
  final bool rejected;

  @override
  State<DocumentsScreen> createState() => _DocumentsScreenState();
}

class _DocumentsScreenState extends State<DocumentsScreen> {
  static const _docs = [
    ('license', 'صورة إجازة السوق', Icons.badge_outlined),
    ('registration', 'صورة سنوية السيارة', Icons.description_outlined),
    ('nationalId', 'البطاقة الوطنية الموحدة', Icons.credit_card),
  ];

  final _picker = ImagePicker();
  final _files = <String, File>{};
  bool _busy = false;

  Future<void> _pick(String key) async {
    final source = await showModalBottomSheet<ImageSource>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(
            leading: const Icon(Icons.photo_camera),
            title: const Text('تصوير بالكاميرا', style: TextStyle(fontSize: 18)),
            onTap: () => Navigator.pop(ctx, ImageSource.camera),
          ),
          ListTile(
            leading: const Icon(Icons.photo_library),
            title: const Text('اختيار من المعرض', style: TextStyle(fontSize: 18)),
            onTap: () => Navigator.pop(ctx, ImageSource.gallery),
          ),
        ]),
      ),
    );
    if (source == null) return;
    try {
      final x = await _picker.pickImage(source: source, imageQuality: 80, maxWidth: 1800);
      if (x != null) setState(() => _files[key] = File(x.path));
    } catch (_) {
      if (mounted) _msg('تعذّر فتح الكاميرا أو المعرض، تحقق من الصلاحيات');
    }
  }

  void _msg(String t) => ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(t)));

  Future<void> _submit() async {
    final repo = context.read<FreightRepository>();
    setState(() => _busy = true);
    try {
      final paths = <String, String>{};
      for (final d in _docs) {
        paths[d.$1] = await repo.uploadFile('driver-docs', '${widget.user.id}/${d.$1}.jpg', _files[d.$1]!);
      }
      await repo.submitDriverDocs(widget.user.id, paths);
      widget.onSubmitted();
    } on FreightException catch (e) {
      if (mounted) _msg(e.message);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final complete = _files.length == _docs.length;
    return Scaffold(
      appBar: AppBar(
        title: const Text('وثائق التدقيق الأمني'),
        actions: [
          const ThemeToggleButton(),
          IconButton(
            tooltip: 'تسجيل الخروج',
            icon: const Icon(Icons.logout),
            onPressed: () => context.read<AuthCubit>().signOut(),
          ),
        ],
      ),
      body: ListView(padding: const EdgeInsets.all(20), children: [
        if (widget.rejected)
          Container(
            margin: const EdgeInsets.only(bottom: 16),
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: cs.errorContainer, borderRadius: BorderRadius.circular(14)),
            child: Text('لم تُقبل وثائقك السابقة. أعد رفع صور واضحة وسليمة.',
                style: TextStyle(color: cs.onErrorContainer, fontWeight: FontWeight.bold, fontSize: 16)),
          ),
        const Text(
          'لحماية التجار والسائقين نراجع وثائقك قبل تفعيل حسابك. صوّر كل وثيقة بوضوح وبإضاءة جيدة.',
          style: TextStyle(fontSize: 17, height: 1.5),
        ),
        const SizedBox(height: 20),
        for (final d in _docs)
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: InkWell(
              borderRadius: BorderRadius.circular(16),
              onTap: _busy ? null : () => _pick(d.$1),
              child: Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  border: Border.all(color: _files[d.$1] != null ? cs.primary : cs.outlineVariant, width: 2),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Row(children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(10),
                    child: Container(
                      width: 72,
                      height: 72,
                      color: cs.surfaceContainerHighest,
                      child: _files[d.$1] != null
                          ? Image.file(_files[d.$1]!, fit: BoxFit.cover)
                          : Icon(d.$3, size: 34, color: cs.primary),
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(d.$2, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                      Text(_files[d.$1] != null ? 'تم الاختيار ✓ (اضغط للتغيير)' : 'اضغط لإضافة الصورة'),
                    ]),
                  ),
                ]),
              ),
            ),
          ),
        const SizedBox(height: 12),
        SizedBox(
          height: 64,
          child: FilledButton(
            onPressed: complete && !_busy ? _submit : null,
            child: _busy
                ? const SizedBox(height: 24, width: 24, child: CircularProgressIndicator(strokeWidth: 3))
                : const Text('إرسال للمراجعة'),
          ),
        ),
      ]),
    );
  }
}
