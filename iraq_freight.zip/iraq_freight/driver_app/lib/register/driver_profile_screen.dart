import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:freight_core/freight_core.dart';

/// تسجيل السائق: الاسم الكامل، المحافظة الرئيسية، نوع المركبة، رقم اللوحة
class DriverProfileScreen extends StatefulWidget {
  const DriverProfileScreen({super.key, required this.user});
  final AppUser user;

  @override
  State<DriverProfileScreen> createState() => _DriverProfileScreenState();
}

class _DriverProfileScreenState extends State<DriverProfileScreen> {
  final _name = TextEditingController();
  final _plate = TextEditingController();
  String? _gov;
  VehicleType? _vehicle;

  @override
  void dispose() {
    _name.dispose();
    _plate.dispose();
    super.dispose();
  }

  bool get _valid =>
      _name.text.trim().length >= 5 && _gov != null && _vehicle != null && _plate.text.trim().length >= 3;

  @override
  Widget build(BuildContext context) {
    final busy = context.watch<AuthCubit>().state.busy;
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: const Text('تسجيل سائق جديد'), actions: const [ThemeToggleButton()]),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Text('بيانات السائق', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          const SizedBox(height: 16),
          TextField(
            controller: _name,
            onChanged: (_) => setState(() {}),
            style: const TextStyle(fontSize: 18),
            decoration: const InputDecoration(labelText: 'الاسم الكامل', prefixIcon: Icon(Icons.person_outline)),
          ),
          const SizedBox(height: 16),
          DropdownMenu<String>(
            label: const Text('المحافظة التي تسكن فيها'),
            expandedInsets: EdgeInsets.zero,
            menuHeight: 320,
            leadingIcon: const Icon(Icons.location_city),
            dropdownMenuEntries: [
              for (final g in IraqData.governorates) DropdownMenuEntry(value: g.id, label: g.nameAr),
            ],
            onSelected: (v) => setState(() => _gov = v),
          ),
          const SizedBox(height: 24),
          const Text('نوع المركبة', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          for (final v in VehicleType.values)
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: InkWell(
                borderRadius: BorderRadius.circular(14),
                onTap: () => setState(() => _vehicle = v),
                child: Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: _vehicle == v ? cs.primaryContainer : null,
                    border: Border.all(
                      color: _vehicle == v ? cs.primary : cs.outlineVariant,
                      width: _vehicle == v ? 2 : 1,
                    ),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Row(children: [
                    Icon(Icons.local_shipping, color: cs.primary, size: 30),
                    const SizedBox(width: 12),
                    Expanded(child: Text(v.label, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600))),
                    if (_vehicle == v) Icon(Icons.check_circle, color: cs.primary),
                  ]),
                ),
              ),
            ),
          const SizedBox(height: 14),
          TextField(
            controller: _plate,
            onChanged: (_) => setState(() {}),
            style: const TextStyle(fontSize: 18),
            decoration: const InputDecoration(
              labelText: 'رقم لوحة المركبة',
              hintText: 'مثال: 12345 ب بغداد',
              prefixIcon: Icon(Icons.pin_outlined),
            ),
          ),
          const SizedBox(height: 28),
          SizedBox(
            height: 64,
            child: FilledButton(
              onPressed: _valid && !busy
                  ? () => context.read<AuthCubit>().completeProfile(widget.user.copyWith(
                        fullName: _name.text.trim(),
                        governorate: _gov,
                        vehicle: _vehicle,
                        plateNumber: _plate.text.trim(),
                      ))
                  : null,
              child: busy
                  ? const SizedBox(height: 24, width: 24, child: CircularProgressIndicator(strokeWidth: 3))
                  : const Text('حفظ والمتابعة'),
            ),
          ),
        ],
      ),
    );
  }
}
