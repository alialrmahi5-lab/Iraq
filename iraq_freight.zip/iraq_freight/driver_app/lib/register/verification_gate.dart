import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:freight_core/freight_core.dart';

import '../home_shell.dart';
import 'documents_screen.dart';

/// بوابة التدقيق الأمني: السائق لا يرى الطلبات إلا بعد اعتماد وثائقه.
///   معتمد  ← الشاشة الرئيسية
///   مرفوض  ← إعادة رفع الوثائق
///   قيد المراجعة ← إن لم يرفع وثائقه بعد: شاشة الرفع، وإلا: شاشة الانتظار
class VerificationGate extends StatefulWidget {
  const VerificationGate({super.key, required this.user});
  final AppUser user;

  @override
  State<VerificationGate> createState() => _VerificationGateState();
}

class _VerificationGateState extends State<VerificationGate> {
  late Future<bool> _submitted = _load();

  Future<bool> _load() => context.read<FreightRepository>().hasSubmittedDocs(widget.user.id);

  void _reload() => setState(() => _submitted = _load());

  @override
  Widget build(BuildContext context) {
    final user = widget.user;
    if (user.verification == VerificationStatus.approved) return HomeShell(user: user);

    if (user.verification == VerificationStatus.rejected) {
      return DocumentsScreen(user: user, rejected: true, onSubmitted: () {
        context.read<AuthCubit>().refresh();
        _reload();
      });
    }

    return FutureBuilder<bool>(
      future: _submitted,
      builder: (context, snap) {
        if (!snap.hasData) return const Scaffold(body: Center(child: CircularProgressIndicator()));
        if (snap.data == false) {
          return DocumentsScreen(user: user, onSubmitted: () {
            // في الوضع التجريبي يُعتمد السائق فوراً، وفي الإنتاج ينتظر مراجعة الإدارة
            context.read<AuthCubit>().refresh();
            _reload();
          });
        }
        return _PendingScreen(user: user);
      },
    );
  }
}

class _PendingScreen extends StatelessWidget {
  const _PendingScreen({required this.user});
  final AppUser user;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('قيد المراجعة'),
        actions: [
          const ThemeToggleButton(),
          IconButton(
            tooltip: 'تسجيل الخروج',
            icon: const Icon(Icons.logout),
            onPressed: () => context.read<AuthCubit>().signOut(),
          ),
        ],
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(Icons.hourglass_top_rounded, size: 90, color: Theme.of(context).colorScheme.primary),
            const SizedBox(height: 20),
            Text('أهلاً ${user.fullName}', style: Theme.of(context).textTheme.headlineSmall),
            const SizedBox(height: 12),
            const Text(
              'استلمنا وثائقك وهي قيد المراجعة الأمنية.\nسيُفعَّل حسابك فور اعتمادها، وتبدأ باستقبال الطلبات.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 18, height: 1.6),
            ),
            const SizedBox(height: 28),
            FilledButton.icon(
              icon: const Icon(Icons.refresh),
              label: const Text('تحديث الحالة'),
              onPressed: () => context.read<AuthCubit>().refresh(),
            ),
          ]),
        ),
      ),
    );
  }
}
