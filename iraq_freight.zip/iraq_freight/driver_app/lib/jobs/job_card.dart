import 'package:flutter/material.dart';
import 'package:freight_core/freight_core.dart';

import '../widgets/slide_to_accept.dart';

/// بطاقة الطلب: مسار الرحلة، نوع الحمولة، المسافة، وصافي الربح بخط كبير،
/// ثم زر السحب للقبول.
class JobCard extends StatelessWidget {
  const JobCard({
    super.key,
    required this.job,
    required this.onAccept,
    this.accepting = false,
    this.highlight = false,
  });

  final Shipment job;
  final VoidCallback onAccept;
  final bool accepting;
  final bool highlight;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Card.outlined(
      margin: const EdgeInsets.only(bottom: 14),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
        side: BorderSide(color: highlight ? cs.primary : cs.outlineVariant, width: highlight ? 3 : 1),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          // مسار الرحلة: بغداد ← البصرة
          Row(children: [
            Flexible(child: Text(job.fromName, style: _route)),
            const Padding(padding: EdgeInsets.symmetric(horizontal: 10), child: Icon(Icons.arrow_forward, size: 28)),
            Flexible(child: Text(job.toName, style: _route)),
          ]),
          const SizedBox(height: 12),
          Wrap(spacing: 8, runSpacing: 8, children: [
            _Chip(Icons.inventory_2_outlined, job.cargo.label),
            _Chip(Icons.scale_outlined, job.weight.range),
            _Chip(Icons.route, '${job.distanceKm.round()} كم'),
            if (job.needsRefrigeration) _Chip(Icons.ac_unit, 'براد / مغلقة'),
          ]),
          if (job.notes.isNotEmpty) ...[
            const SizedBox(height: 10),
            Text('ملاحظة: ${job.notes}', style: TextStyle(color: cs.onSurfaceVariant)),
          ],
          const SizedBox(height: 14),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 14),
            decoration: BoxDecoration(color: Colors.green.withAlpha(30), borderRadius: BorderRadius.circular(14)),
            child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              const Text('صافي ربحك', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
              Text(
                formatIqd(job.driverNet),
                style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w800, color: Colors.green),
              ),
            ]),
          ),
          const SizedBox(height: 14),
          SlideToAcceptButton(label: 'اسحب لقبول الطلب', busy: accepting, onAccepted: onAccept),
        ]),
      ),
    );
  }

  static const _route = TextStyle(fontSize: 24, fontWeight: FontWeight.w800);
}

class _Chip extends StatelessWidget {
  const _Chip(this.icon, this.text);
  final IconData icon;
  final String text;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(color: cs.surfaceContainerHighest, borderRadius: BorderRadius.circular(10)),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(icon, size: 18),
        const SizedBox(width: 6),
        Text(text, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
      ]),
    );
  }
}
