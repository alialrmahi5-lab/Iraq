import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:freight_core/freight_core.dart';

import '../active/trip_cubit.dart';
import 'job_card.dart';
import 'jobs_cubit.dart';

/// جدار الطلبات: قائمة حية بالشحنات المتاحة المطابقة لسيارة السائق.
class JobsScreen extends StatelessWidget {
  const JobsScreen({super.key, required this.driver, required this.onAccepted});
  final AppUser driver;

  /// يُستدعى بعد قبول طلب بنجاح (ينقل السائق لتبويب الرحلة)
  final VoidCallback onAccepted;

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<JobsCubit, JobsState>(
      listenWhen: (a, b) => b.error != null && a.error != b.error,
      listener: (context, s) => ScaffoldMessenger.of(context)
        ..hideCurrentSnackBar()
        ..showSnackBar(SnackBar(content: Text(s.error!))),
      builder: (context, s) {
        final jobs = s.visible;
        return Column(children: [
          _Header(driver: driver, state: s),
          Expanded(
            child: s.loading
                ? const Center(child: CircularProgressIndicator())
                : jobs.isEmpty
                    ? _Empty(state: s)
                    : ListView.builder(
                        padding: const EdgeInsets.fromLTRB(12, 4, 12, 24),
                        itemCount: jobs.length,
                        itemBuilder: (context, i) {
                          final job = jobs[i];
                          return JobCard(
                            key: ValueKey(job.id),
                            job: job,
                            accepting: s.acceptingId == job.id,
                            highlight: s.alert?.id == job.id,
                            onAccept: () => _accept(context, job),
                          );
                        },
                      ),
          ),
        ]);
      },
    );
  }

  Future<void> _accept(BuildContext context, Shipment job) async {
    final jobsCubit = context.read<JobsCubit>();
    final trip = context.read<TripCubit>();
    final accepted = await jobsCubit.accept(job.id);
    if (accepted != null) {
      trip.adopt(accepted); // يظهر فوراً في تبويب الرحلة + يطلق سؤال «الرجعة»
      onAccepted();
    }
  }
}

class _Header extends StatelessWidget {
  const _Header({required this.driver, required this.state});
  final AppUser driver;
  final JobsState state;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final cubit = context.read<JobsCubit>();
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 8),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        if (state.backhaul)
          Container(
            margin: const EdgeInsets.only(bottom: 10),
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(color: cs.tertiaryContainer, borderRadius: BorderRadius.circular(14)),
            child: Row(children: [
              Icon(Icons.u_turn_left, color: cs.onTertiaryContainer),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  'طلبات الرجعة: من ${IraqData.nameOf(state.originGov)} والمحافظات القريبة',
                  style: TextStyle(fontWeight: FontWeight.bold, color: cs.onTertiaryContainer),
                ),
              ),
              TextButton(onPressed: cubit.resetOrigin, child: const Text('إلغاء')),
            ]),
          ),
        Text(
          'سيارتك: ${driver.vehicle?.label ?? '-'}  ·  ${IraqData.nameOf(state.originGov)}',
          style: Theme.of(context).textTheme.titleSmall,
        ),
        const SizedBox(height: 8),
        Wrap(spacing: 8, children: [
          for (final sc in JobScope.values)
            ChoiceChip(
              label: Text(sc.label, style: const TextStyle(fontSize: 15)),
              selected: state.scope == sc,
              onSelected: (_) => cubit.setScope(sc),
            ),
        ]),
      ]),
    );
  }
}

class _Empty extends StatelessWidget {
  const _Empty({required this.state});
  final JobsState state;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(Icons.hourglass_empty, size: 72, color: Theme.of(context).colorScheme.outline),
          const SizedBox(height: 16),
          Text('لا توجد طلبات مناسبة الآن', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 8),
          Text(
            state.soundOn
                ? 'اترك التطبيق مفتوحاً، سنُنبّهك بصوت عالٍ عند وصول طلب جديد'
                : 'التنبيه الصوتي متوقف، فعّله من أيقونة السماعة بالأعلى',
            textAlign: TextAlign.center,
          ),
          if (state.scope != JobScope.all) ...[
            const SizedBox(height: 16),
            OutlinedButton(
              onPressed: () => context.read<JobsCubit>().setScope(JobScope.all),
              child: const Text('عرض كل الطلبات'),
            ),
          ],
        ]),
      ),
    );
  }
}
