import 'dart:async';

import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:freight_core/freight_core.dart';

import 'alert_sound.dart';

/// نطاق عرض الطلبات في جدار الطلبات
enum JobScope {
  fromMyGov('من محافظتي'),
  nearby('القريبة'),
  all('كل الطلبات');

  const JobScope(this.label);
  final String label;
}

class JobsState extends Equatable {
  const JobsState({
    this.open = const [],
    this.loading = true,
    required this.originGov,
    this.backhaul = false,
    this.scope = JobScope.nearby,
    this.alert,
    this.soundOn = true,
    this.acceptingId,
    this.error,
  });

  /// الطلبات المفتوحة المطابقة لنوع مركبة السائق (قبل تطبيق فلتر النطاق)
  final List<Shipment> open;
  final bool loading;

  /// نقطة الاعتماد للفلترة: محافظة السائق، أو وجهة رحلته عند البحث عن «رجعة»
  final String originGov;
  final bool backhaul;
  final JobScope scope;

  /// الطلب الجديد الذي يُصدر التنبيه الآن (null = لا تنبيه)
  final Shipment? alert;
  final bool soundOn;
  final String? acceptingId;
  final String? error;

  bool inScope(Shipment s) => switch (scope) {
        JobScope.fromMyGov => s.fromGov == originGov,
        JobScope.nearby => s.fromGov == originGov || IraqData.nearby(originGov).contains(s.fromGov),
        JobScope.all => true,
      };

  List<Shipment> get visible => open.where(inScope).toList();

  JobsState copyWith({
    List<Shipment>? open,
    bool? loading,
    String? originGov,
    bool? backhaul,
    JobScope? scope,
    Shipment? alert,
    bool clearAlert = false,
    bool? soundOn,
    String? acceptingId,
    bool clearAccepting = false,
    String? error,
  }) =>
      JobsState(
        open: open ?? this.open,
        loading: loading ?? this.loading,
        originGov: originGov ?? this.originGov,
        backhaul: backhaul ?? this.backhaul,
        scope: scope ?? this.scope,
        alert: clearAlert ? null : (alert ?? this.alert),
        soundOn: soundOn ?? this.soundOn,
        acceptingId: clearAccepting ? null : (acceptingId ?? this.acceptingId),
        error: error, // يُمسح تلقائياً ما لم يُمرَّر
      );

  @override
  List<Object?> get props =>
      [open, loading, originGov, backhaul, scope, alert, soundOn, acceptingId, error];
}

/// قلب تطبيق السائق: جدار الطلبات الحي + التنبيه الصوتي + قبول الطلب + الرجعة.
///
/// التدفق:
///  1. الاشتراك بتيار الطلبات المفتوحة (Realtime).
///  2. الإبقاء على الطلبات المطابقة لنوع مركبة السائق فقط.
///  3. أي طلب «جديد» (لم يُرَ سابقاً) داخل النطاق الحالي يفعّل التنبيه الصوتي المتكرر.
///  4. القبول عملية ذرّية في الخادم؛ إن سبقه سائق آخر يظهر خطأ واضح.
class JobsCubit extends Cubit<JobsState> {
  JobsCubit(this._repo, this._sound, this._driver)
      : super(JobsState(originGov: _driver.governorate ?? 'baghdad')) {
    _sub = _repo.watchOpenShipments().listen(
          _onData,
          onError: (_) => emit(state.copyWith(loading: false, error: 'تعذّر تحديث الطلبات، تحقق من الاتصال')),
        );
  }

  final FreightRepository _repo;
  final AlertSound _sound;
  final AppUser _driver;
  late final StreamSubscription<List<Shipment>> _sub;

  final _seen = <String>{};

  /// طلبات تأكدنا أن سائقاً آخر أخذها (قد يتأخر وصول التحديث من الخادم)
  final _hidden = <String>{};
  bool _initialized = false;
  Timer? _alertTimeout;

  /// أقصى مدة لتكرار الصفارة إن لم يتفاعل السائق
  static const alertMaxDuration = Duration(seconds: 60);

  void _onData(List<Shipment> list) {
    final mine = list.where((s) => s.vehicle == _driver.vehicle && !_hidden.contains(s.id)).toList();

    // أول تحميل: نسجّل الطلبات الموجودة ولا ننبّه عليها
    Shipment? fresh;
    if (_initialized) {
      for (final s in mine) {
        if (!_seen.contains(s.id) && state.inScope(s)) {
          fresh = s;
          break;
        }
      }
    }
    _seen.addAll(mine.map((s) => s.id));
    _initialized = true;

    // إن اختفى الطلب الذي يُنبَّه عليه (أخذه سائق آخر) نوقف الصوت
    var clearAlert = false;
    final cur = state.alert;
    if (cur != null && !mine.any((s) => s.id == cur.id)) {
      clearAlert = true;
      _stopAlert();
    }

    emit(state.copyWith(open: mine, loading: false, clearAlert: clearAlert));

    if (fresh != null) _raiseAlert(fresh);
  }

  void _raiseAlert(Shipment job) {
    emit(state.copyWith(alert: job));
    if (state.soundOn) _sound.start();
    _alertTimeout?.cancel();
    _alertTimeout = Timer(alertMaxDuration, dismissAlert);
  }

  void _stopAlert() {
    _alertTimeout?.cancel();
    _sound.stop();
  }

  /// إغلاق التنبيه وإيقاف الصوت (تجاهل / عرض الطلب / انتهاء المهلة)
  void dismissAlert() {
    _stopAlert();
    if (!isClosed && state.alert != null) emit(state.copyWith(clearAlert: true));
  }

  void toggleSound() {
    final on = !state.soundOn;
    if (!on) _sound.stop();
    emit(state.copyWith(soundOn: on));
  }

  void setScope(JobScope s) => emit(state.copyWith(scope: s));

  /// «الرجعة الفارغة»: عرض الطلبات المنطلقة من (أو قرب) محافظة وصول الرحلة الحالية
  void showBackhaulFrom(String gov) =>
      emit(state.copyWith(originGov: gov, backhaul: true, scope: JobScope.nearby));

  /// العودة لمحافظة السائق الأساسية
  void resetOrigin() => emit(state.copyWith(
        originGov: _driver.governorate ?? 'baghdad',
        backhaul: false,
      ));

  /// قبول طلب. يعيد الشحنة المقبولة (مع بيانات التاجر) أو null عند الفشل.
  Future<Shipment?> accept(String id) async {
    if (state.acceptingId != null) return null;
    emit(state.copyWith(acceptingId: id));
    try {
      final s = await _repo.acceptShipment(id, _driver);
      dismissAlert();
      emit(state.copyWith(clearAccepting: true));
      return s;
    } on FreightException catch (e) {
      if (e.code == FreightException.taken) {
        // سبقه سائق آخر: نخفي الطلب فوراً ونوقف صوته إن كان هو المنبَّه عليه
        _hidden.add(id);
        if (state.alert?.id == id) _stopAlert();
        emit(state.copyWith(
          open: state.open.where((s) => s.id != id).toList(),
          clearAccepting: true,
          clearAlert: state.alert?.id == id,
          error: e.message,
        ));
      } else {
        emit(state.copyWith(clearAccepting: true, error: e.message));
      }
      return null;
    }
  }

  @override
  Future<void> close() async {
    _alertTimeout?.cancel();
    await _sub.cancel();
    await _sound.dispose();
    return super.close();
  }
}
