import 'package:audioplayers/audioplayers.dart';

/// واجهة صوت التنبيه (تُحقن في JobsCubit ليسهل اختبارها)
abstract class AlertSound {
  Future<void> start();
  Future<void> stop();
  Future<void> dispose();
}

/// صفارة متكررة عالية تعمل على قناة «المنبّه» في أندرويد
/// فيُسمع الصوت حتى لو كان صوت الوسائط منخفضاً أثناء القيادة.
class SirenAlertSound implements AlertSound {
  final AudioPlayer _player = AudioPlayer();
  bool _playing = false;

  @override
  Future<void> start() async {
    if (_playing) return;
    _playing = true;
    try {
      await _player.setAudioContext(AudioContext(
        android: AudioContextAndroid(
          usageType: AndroidUsageType.alarm,
          contentType: AndroidContentType.sonification,
          audioFocus: AndroidAudioFocus.gain,
        ),
      ));
      await _player.setReleaseMode(ReleaseMode.loop); // تكرار بلا توقف حتى الإيقاف
      await _player.setVolume(1.0);
      await _player.play(AssetSource('sounds/alert.wav'));
    } catch (_) {
      _playing = false; // فشل الصوت لا يجب أن يعطّل التطبيق
    }
  }

  @override
  Future<void> stop() async {
    if (!_playing) return;
    _playing = false;
    try {
      await _player.stop();
    } catch (_) {}
  }

  @override
  Future<void> dispose() async {
    await stop();
    await _player.dispose();
  }
}
