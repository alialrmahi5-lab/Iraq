import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:image_picker/image_picker.dart';

import 'trip_cubit.dart';

/// إثبات التوصيل: تصوير الوصل الورقي الموقّع من المستلم ثم إغلاق الطلب.
class ProofScreen extends StatefulWidget {
  const ProofScreen({super.key});

  @override
  State<ProofScreen> createState() => _ProofScreenState();
}

class _ProofScreenState extends State<ProofScreen> {
  final _picker = ImagePicker();
  File? _photo;

  Future<void> _capture() async {
    try {
      final x = await _picker.pickImage(
        source: ImageSource.camera,
        imageQuality: 70, // تقليل الحجم للإنترنت الضعيف على الطرق الخارجية
        maxWidth: 1600,
      );
      if (x != null) setState(() => _photo = File(x.path));
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تعذّر فتح الكاميرا، تأكد من منح صلاحية الكاميرا للتطبيق')),
      );
    }
  }

  Future<void> _submit() async {
    final cubit = context.read<TripCubit>();
    final messenger = ScaffoldMessenger.of(context);
    final nav = Navigator.of(context);
    final ok = await cubit.completeWithProof(_photo!);
    if (ok) {
      messenger.showSnackBar(const SnackBar(content: Text('تم تسليم الشحنة وإغلاق الطلب. شكراً لك ✅')));
      nav.pop();
    }
  }

  @override
  Widget build(BuildContext context) {
    final busy = context.select((TripCubit c) => c.state.busy);
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: const Text('إثبات التوصيل')),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(children: [
            const Text(
              'صوّر الوصل الورقي بعد أن يوقّع عليه المستلم، وتأكد أن الصورة واضحة.',
              style: TextStyle(fontSize: 17, height: 1.5),
            ),
            const SizedBox(height: 16),
            Expanded(
              child: GestureDetector(
                onTap: busy ? null : _capture,
                child: Container(
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: cs.surfaceContainerHighest,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: cs.outlineVariant),
                  ),
                  clipBehavior: Clip.antiAlias,
                  child: _photo == null
                      ? Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                          Icon(Icons.photo_camera_outlined, size: 72, color: cs.primary),
                          const SizedBox(height: 8),
                          const Text('اضغط لفتح الكاميرا', style: TextStyle(fontSize: 18)),
                        ])
                      : Image.file(_photo!, fit: BoxFit.cover),
                ),
              ),
            ),
            const SizedBox(height: 16),
            if (_photo != null)
              OutlinedButton.icon(
                icon: const Icon(Icons.refresh),
                label: const Text('إعادة التصوير'),
                onPressed: busy ? null : _capture,
              ),
            const SizedBox(height: 10),
            SizedBox(
              height: 68,
              child: FilledButton.icon(
                icon: busy
                    ? const SizedBox(height: 24, width: 24, child: CircularProgressIndicator(strokeWidth: 3))
                    : const Icon(Icons.verified),
                label: const Text('تأكيد التسليم وإغلاق الطلب', style: TextStyle(fontSize: 19)),
                onPressed: (_photo == null || busy) ? null : _submit,
              ),
            ),
          ]),
        ),
      ),
    );
  }
}
