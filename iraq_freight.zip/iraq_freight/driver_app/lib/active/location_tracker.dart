import 'dart:async';

import 'package:location/location.dart';

/// تتبع موقع السائق أثناء الرحلة.
///
/// يفعّل «وضع الخلفية» في مكتبة location، وهو خدمة أمامية (Foreground Service)
/// بإشعار دائم، فيستمر الإرسال حتى لو أُغلقت الشاشة أو انتقل السائق لتطبيق الملاحة.
/// يُرسَل الموقع مرة كل [interval] (30 ثانية افتراضياً).
class LocationTracker {
  LocationTracker({this.interval = const Duration(seconds: 30)});

  final Duration interval;
  final Location _location = Location();
  StreamSubscription<LocationData>? _sub;
  DateTime? _lastSent;

  bool get running => _sub != null;

  /// يعيد false إن رفض السائق الإذن أو كان GPS مغلقاً.
  Future<bool> start(void Function(double lat, double lng) onFix) async {
    if (running) return true;
    try {
      var enabled = await _location.serviceEnabled();
      if (!enabled) enabled = await _location.requestService();
      if (!enabled) return false;

      var perm = await _location.hasPermission();
      if (perm == PermissionStatus.denied) perm = await _location.requestPermission();
      if (perm != PermissionStatus.granted && perm != PermissionStatus.grantedLimited) return false;

      // الخدمة الأمامية: إشعار «الرحلة قيد التنفيذ»
      try {
        await _location.changeNotificationOptions(
          title: 'رحلة شحن قيد التنفيذ',
          subtitle: 'يتم إرسال موقعك للتاجر',
          onTapBringToFront: true,
        );
        await _location.enableBackgroundMode(enable: true);
      } catch (_) {
        // إن فشل وضع الخلفية نكمل بالتتبع أثناء ظهور التطبيق فقط
      }

      await _location.changeSettings(
        accuracy: LocationAccuracy.high,
        interval: interval.inMilliseconds,
        distanceFilter: 0,
      );

      _lastSent = null;
      _sub = _location.onLocationChanged.listen((d) {
        final lat = d.latitude, lng = d.longitude;
        if (lat == null || lng == null) return;
        final now = DateTime.now();
        // خنق الإرسال: أول موقع فوراً ثم كل 30 ثانية
        if (_lastSent != null && now.difference(_lastSent!) < interval - const Duration(seconds: 2)) return;
        _lastSent = now;
        onFix(lat, lng);
      });
      return true;
    } catch (_) {
      return false;
    }
  }

  Future<void> stop() async {
    await _sub?.cancel();
    _sub = null;
    try {
      await _location.enableBackgroundMode(enable: false);
    } catch (_) {}
  }
}
