import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:freight_core/freight_core.dart';

import 'proof_screen.dart';
import 'trip_cubit.dart';

/// تبويب «رحلتي»: بيانات الرحلة الحالية وأزرار تنفيذها.
class TripScreen extends StatelessWidget {
  const TripScreen({super.key, required this.onFindBackhaul});

  /// يُستدعى عند اختيار «اعرض الطلبات» في سؤال الرجعة، مع محافظة الوصول
  final void Function(String gov) onFindBackhaul;

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<TripCubit, TripState>(
      listenWhen: (a, b) =>
          (!a.backhaulPrompt && b.backhaulPrompt) || (b.error != null && a.error != b.error),
      listener: (context, s) {
        if (s.error != null) {
          ScaffoldMessenger.of(context)
            ..hideCurrentSnackBar()
            ..showSnackBar(SnackBar(content: Text(s.error!)));
        }
        if (s.backhaulPrompt && s.trip != null) _askBackhaul(context, s.trip!);
      },
      builder: (context, s) {
        final t = s.trip;
        if (s.loading) return const Center(child: CircularProgressIndicator());
        if (t == null) return const _NoTrip();
        return ListView(padding: const EdgeInsets.all(16), children: [
          _RouteCard(trip: t),
          const SizedBox(height: 12),
          _MerchantCard(trip: t),
          const SizedBox(height: 12),
          _GpsRow(state: s),
          const SizedBox(height: 16),
          _NavigateButton(trip: t),
          const SizedBox(height: 12),
          _ActionButton(state: s),
          const SizedBox(height: 20),
          _BackhaulBanner(trip: t, onTap: () => onFindBackhaul(t.toGov)),
        ]);
      },
    );
  }

  /// ميزة «الرجعة الفارغة الذكية»: سؤال يظهر مباشرة بعد قبول الرحلة
  Future<void> _askBackhaul(BuildContext context, Shipment trip) async {
    final cubit = context.read<TripCubit>();
    cubit.ackBackhaulPrompt();
    final yes = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        icon: const Icon(Icons.u_turn_left, size: 40),
        title: const Text('رجعة بدون فراغ؟'),
        content: Text(
          'هل تبحث عن حمولة لرحلة العودة من ${trip.toName} إلى ${trip.fromName} أو المحافظات القريبة؟\n\n'
          'اضغط هنا لعرض الطلبات المتاحة.',
          style: const TextStyle(fontSize: 17, height: 1.5),
        ),
        actionsAlignment: MainAxisAlignment.spaceBetween,
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('لاحقاً')),
          FilledButton(
            style: FilledButton.styleFrom(minimumSize: const Size(160, 52)),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('اعرض الطلبات'),
          ),
        ],
      ),
    );
    if (yes == true) onFindBackhaul(trip.toGov);
  }
}

class _NoTrip extends StatelessWidget {
  const _NoTrip();

  @override
  Widget build(BuildContext context) => Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(Icons.local_shipping_outlined, size: 80, color: Theme.of(context).colorScheme.outline),
            const SizedBox(height: 16),
            Text('لا توجد رحلة حالية', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 8),
            const Text('اقبل طلباً من تبويب «الطلبات» لتبدأ رحلتك', textAlign: TextAlign.center),
          ]),
        ),
      );
}

class _RouteCard extends StatelessWidget {
  const _RouteCard({required this.trip});
  final Shipment trip;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Card.outlined(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Flexible(child: Text(trip.fromName, style: _big)),
            const Padding(padding: EdgeInsets.symmetric(horizontal: 10), child: Icon(Icons.arrow_forward, size: 28)),
            Flexible(child: Text(trip.toName, style: _big)),
          ]),
          const SizedBox(height: 10),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(color: cs.primaryContainer, borderRadius: BorderRadius.circular(20)),
            child: Text(trip.status.label,
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: cs.onPrimaryContainer)),
          ),
          const SizedBox(height: 12),
          Text('${trip.cargo.label} · ${trip.weight.range} · ${trip.distanceKm.round()} كم',
              style: const TextStyle(fontSize: 16)),
          if (trip.needsRefrigeration) const Text('⚠️ مطلوب براد / سيارة مغلقة', style: TextStyle(fontSize: 16)),
          if (trip.notes.isNotEmpty) Text('ملاحظة التاجر: ${trip.notes}', style: const TextStyle(fontSize: 16)),
          const Divider(height: 24),
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text('الدفع: ${trip.paymentMethod.label}'),
            Text(formatIqd(trip.driverNet),
                style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: Colors.green)),
          ]),
        ]),
      ),
    );
  }

  static const _big = TextStyle(fontSize: 24, fontWeight: FontWeight.w800);
}

/// بيانات التاجر تظهر بعد القبول مع زر اتصال مباشر وزر واتساب
class _MerchantCard extends StatelessWidget {
  const _MerchantCard({required this.trip});
  final Shipment trip;

  @override
  Widget build(BuildContext context) {
    final phone = trip.merchantPhone;
    return Card.outlined(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('بيانات التاجر', style: TextStyle(fontSize: 14)),
          const SizedBox(height: 4),
          Text(trip.merchantName ?? 'التاجر', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          if (phone != null) ...[
            Text(phone, textDirection: TextDirection.ltr, style: const TextStyle(fontSize: 16)),
            const SizedBox(height: 12),
            Row(children: [
              Expanded(
                child: FilledButton.icon(
                  style: FilledButton.styleFrom(backgroundColor: Colors.green, foregroundColor: Colors.white),
                  icon: const Icon(Icons.call),
                  label: const Text('اتصال'),
                  onPressed: () => callPhone(phone),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: FilledButton.icon(
                  style: FilledButton.styleFrom(backgroundColor: const Color(0xFF25D366), foregroundColor: Colors.white),
                  icon: const Icon(Icons.chat),
                  label: const Text('واتساب'),
                  onPressed: () => openWhatsApp(phone, text: 'السلام عليكم، أنا سائق شحنتك من ${trip.fromName} إلى ${trip.toName}'),
                ),
              ),
            ]),
          ],
        ]),
      ),
    );
  }
}

class _GpsRow extends StatelessWidget {
  const _GpsRow({required this.state});
  final TripState state;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    switch (state.gps) {
      case GpsStatus.active:
        return Row(children: [
          const Icon(Icons.gps_fixed, color: Colors.green),
          const SizedBox(width: 8),
          Expanded(child: Text('الموقع يُرسل للتاجر كل 30 ثانية', style: TextStyle(color: cs.onSurfaceVariant))),
        ]);
      case GpsStatus.denied:
        return Card(
          color: cs.errorContainer,
          child: ListTile(
            leading: Icon(Icons.gps_off, color: cs.onErrorContainer),
            title: Text('فعّل الموقع (GPS) وصلاحيته ليتابع التاجر شحنته',
                style: TextStyle(color: cs.onErrorContainer, fontWeight: FontWeight.bold)),
            trailing: TextButton(
              onPressed: () => context.read<TripCubit>().retryGps(),
              child: const Text('إعادة المحاولة'),
            ),
          ),
        );
      case GpsStatus.off:
        return const SizedBox.shrink();
    }
  }
}

/// ملاحظة: قبل التحميل نوجّه السائق لموقع التحميل، وبعده لنقطة التسليم
class _NavigateButton extends StatelessWidget {
  const _NavigateButton({required this.trip});
  final Shipment trip;

  @override
  Widget build(BuildContext context) {
    final toPickup = trip.status == ShipmentStatus.accepted;
    return OutlinedButton.icon(
      icon: const Icon(Icons.navigation),
      label: Text(toPickup ? 'ملاحة إلى موقع التحميل' : 'ملاحة إلى نقطة التسليم'),
      onPressed: () => toPickup ? openNavigation(trip.fromLat, trip.fromLng) : openNavigation(trip.toLat, trip.toLng),
    );
  }
}

/// الزر الكبير لتحديث الحالة: وصلت للتحميل ← في الطريق ← وصلت للتسليم ← إثبات التوصيل
class _ActionButton extends StatelessWidget {
  const _ActionButton({required this.state});
  final TripState state;

  @override
  Widget build(BuildContext context) {
    final t = state.trip!;
    final isProof = t.status == ShipmentStatus.atDropoff;
    return SizedBox(
      height: 72,
      child: FilledButton.icon(
        icon: state.busy
            ? const SizedBox(height: 24, width: 24, child: CircularProgressIndicator(strokeWidth: 3))
            : Icon(isProof ? Icons.photo_camera : Icons.check_circle_outline, size: 28),
        label: Text(TripCubit.actionLabel(t.status), style: const TextStyle(fontSize: 20)),
        onPressed: state.busy
            ? null
            : () {
                final cubit = context.read<TripCubit>();
                if (isProof) {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => BlocProvider.value(value: cubit, child: const ProofScreen())),
                  );
                } else {
                  cubit.advance();
                }
              },
      ),
    );
  }
}

class _BackhaulBanner extends StatelessWidget {
  const _BackhaulBanner({required this.trip, required this.onTap});
  final Shipment trip;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Card(
      color: cs.tertiaryContainer,
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(children: [
            Icon(Icons.u_turn_left, size: 32, color: cs.onTertiaryContainer),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                'ابحث عن حمولة للعودة من ${trip.toName} بدل الرجوع فارغاً',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: cs.onTertiaryContainer),
              ),
            ),
            Icon(Icons.chevron_left, color: cs.onTertiaryContainer),
          ]),
        ),
      ),
    );
  }
}
