import 'dart:async';
import 'dart:io';

import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:freight_core/freight_core.dart';

import 'location_tracker.dart';

enum GpsStatus { off, active, denied }

class TripState extends Equatable {
  const TripState({
    this.trip,
    this.loading = true,
    this.busy = false,
    this.gps = GpsStatus.off,
    this.lastSent,
    this.backhaulPrompt = false,
    this.error,
  });

  final Shipment? trip;
  final bool loading;
  final bool busy;
  final GpsStatus gps;
  final DateTime? lastSent;

  /// true مباشرة بعد قبول رحلة: يطلب من الواجهة عرض سؤال «الرجعة»
  final bool backhaulPrompt;
  final String? error;

  TripState copyWith({
    Shipment? trip,
    bool clearTrip = false,
    bool? loading,
    bool? busy,
    GpsStatus? gps,
    DateTime? lastSent,
    bool? backhaulPrompt,
    String? error,
  }) =>
      TripState(
        trip: clearTrip ? null : (trip ?? this.trip),
        loading: loading ?? this.loading,
        busy: busy ?? false,
        gps: gps ?? this.gps,
        lastSent: lastSent ?? this.lastSent,
        backhaulPrompt: backhaulPrompt ?? this.backhaulPrompt,
        error: error,
      );

  @override
  List<Object?> get props => [trip, loading, busy, gps, lastSent, backhaulPrompt, error];
}

/// الرحلة الجارية: حالتها، تتبع GPS كل 30 ثانية، أزرار تحديث الحالة، وإثبات التوصيل.
class TripCubit extends Cubit<TripState> {
  TripCubit(this._repo, this._tracker, this._driver) : super(const TripState()) {
    _sub = _repo.watchDriverShipments(_driver.id).listen(
          _onList,
          onError: (_) => emit(state.copyWith(loading: false)),
        );
  }

  final FreightRepository _repo;
  final LocationTracker _tracker;
  final AppUser _driver;
  late final StreamSubscription<List<Shipment>> _sub;
  bool _trackingRequested = false;

  /// الحالة التالية عند الضغط على الزر الكبير (null = حان وقت إثبات التوصيل)
  static ShipmentStatus? nextOf(ShipmentStatus s) => switch (s) {
        ShipmentStatus.accepted => ShipmentStatus.atPickup,
        ShipmentStatus.atPickup => ShipmentStatus.inTransit,
        ShipmentStatus.inTransit => ShipmentStatus.atDropoff,
        _ => null,
      };

  /// نص الزر الكبير لكل حالة
  static String actionLabel(ShipmentStatus s) => switch (s) {
        ShipmentStatus.accepted => 'وصلت لموقع التحميل',
        ShipmentStatus.atPickup => 'في الطريق للوصول',
        ShipmentStatus.inTransit => 'وصلت لنقطة التسليم',
        ShipmentStatus.atDropoff => 'إثبات التوصيل (تصوير الوصل)',
        _ => '',
      };

  void _onList(List<Shipment> list) {
    Shipment? next;
    final cur = state.trip;
    if (cur != null) {
      final updated = list.where((s) => s.id == cur.id);
      // إن لم تصل الشحنة بعد من الخادم (سباق بعد القبول) نُبقي النسخة الحالية
      if (updated.isEmpty) {
        next = cur;
      } else if (updated.first.status.isOngoing) {
        next = updated.first;
      }
    }
    next ??= list.where((s) => s.status.isOngoing).firstOrNull;
    emit(state.copyWith(trip: next, clearTrip: next == null, loading: false));
    _syncTracking(next);
  }

  /// تشغيل/إيقاف خدمة GPS تبعاً لوجود رحلة جارية
  Future<void> _syncTracking(Shipment? trip) async {
    if (trip != null && !_trackingRequested) {
      _trackingRequested = true;
      final ok = await _tracker.start(_onFix);
      if (!isClosed) emit(state.copyWith(gps: ok ? GpsStatus.active : GpsStatus.denied));
      if (!ok) _trackingRequested = false; // نسمح بإعادة المحاولة
    } else if (trip == null && _trackingRequested) {
      _trackingRequested = false;
      await _tracker.stop();
      if (!isClosed) emit(state.copyWith(gps: GpsStatus.off));
    }
  }

  /// يُستدعى كل 30 ثانية من LocationTracker
  Future<void> _onFix(double lat, double lng) async {
    final id = state.trip?.id;
    if (id == null) return;
    try {
      await _repo.pushDriverLocation(id, lat, lng);
      if (!isClosed) emit(state.copyWith(lastSent: DateTime.now()));
    } catch (_) {
      // انقطاع مؤقت: المحاولة التالية بعد 30 ثانية
    }
  }

  /// إعادة محاولة تشغيل GPS (بعد أن يفعّله السائق)
  Future<void> retryGps() => _syncTracking(state.trip);

  /// يُستدعى بعد قبول طلب ليظهر فوراً في تبويب الرحلة دون انتظار التيار
  void adopt(Shipment s) {
    emit(state.copyWith(trip: s, loading: false, backhaulPrompt: true));
    _syncTracking(s);
  }

  void ackBackhaulPrompt() => emit(state.copyWith(backhaulPrompt: false));

  /// الضغط على الزر الكبير: تحديث الحالة للمرحلة التالية
  Future<void> advance() async {
    final t = state.trip;
    if (t == null || state.busy) return;
    final next = nextOf(t.status);
    if (next == null) return;
    emit(state.copyWith(busy: true));
    try {
      await _repo.updateStatus(t.id, next);
      emit(state.copyWith(trip: t.copyWith(status: next)));
    } on FreightException catch (e) {
      emit(state.copyWith(error: e.message));
    }
  }

  /// إثبات التوصيل: رفع صورة الوصل الموقّع ثم إغلاق الطلب. يعيد true عند النجاح.
  Future<bool> completeWithProof(File photo) async {
    final t = state.trip;
    if (t == null || state.busy) return false;
    emit(state.copyWith(busy: true));
    try {
      final path = await _repo.uploadFile('delivery-proofs', '${_driver.id}/${t.id}.jpg', photo);
      await _repo.completeWithProof(t.id, path);
      emit(state.copyWith(clearTrip: true));
      await _syncTracking(null);
      return true;
    } on FreightException catch (e) {
      emit(state.copyWith(error: e.message));
      return false;
    }
  }

  @override
  Future<void> close() async {
    await _sub.cancel();
    await _tracker.stop();
    return super.close();
  }
}
