import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:freight_core/freight_core.dart';

import 'active/location_tracker.dart';
import 'active/trip_cubit.dart';
import 'active/trip_screen.dart';
import 'jobs/alert_sound.dart';
import 'jobs/jobs_cubit.dart';
import 'jobs/jobs_screen.dart';

/// الغلاف الرئيسي بعد اعتماد السائق: تبويب «الطلبات» و«رحلتي».
/// يهيّئ JobsCubit (جدار الطلبات + التنبيه) و TripCubit (الرحلة + GPS).
class HomeShell extends StatelessWidget {
  const HomeShell({super.key, required this.user});
  final AppUser user;

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider(create: (ctx) => JobsCubit(ctx.read<FreightRepository>(), SirenAlertSound(), user)),
        BlocProvider(create: (ctx) => TripCubit(ctx.read<FreightRepository>(), LocationTracker(), user)),
      ],
      child: _ShellBody(user: user),
    );
  }
}

class _ShellBody extends StatefulWidget {
  const _ShellBody({required this.user});
  final AppUser user;

  @override
  State<_ShellBody> createState() => _ShellBodyState();
}

class _ShellBodyState extends State<_ShellBody> {
  int _tab = 0;
  bool _alertOpen = false;

  void _go(int i) => setState(() => _tab = i);

  /// «الرجعة الفارغة»: فلترة الجدار على وجهة الرحلة والانتقال له
  void _findBackhaul(String gov) {
    context.read<JobsCubit>().showBackhaulFrom(gov);
    _go(0);
  }

  /// نافذة التنبيه: تظهر مع الصفارة وتُغلق عند التفاعل أو إن أخذ سائق آخر الطلب
  void _onAlert(BuildContext context, JobsState s) {
    if (s.alert != null && !_alertOpen) {
      _alertOpen = true;
      final jobs = context.read<JobsCubit>();
      showDialog<void>(
        context: context,
        barrierDismissible: false,
        builder: (_) => _NewJobDialog(
          job: s.alert!,
          onView: () {
            jobs.dismissAlert();
            _go(0);
          },
          onIgnore: jobs.dismissAlert,
        ),
      ).then((_) {
        // يشمل الإغلاق بزر الرجوع: نوقف الصوت في كل الأحوال
        _alertOpen = false;
        jobs.dismissAlert();
      });
    } else if (s.alert == null && _alertOpen) {
      _alertOpen = false;
      Navigator.of(context, rootNavigator: true).pop();
    }
  }

  Future<void> _logout() async {
    final auth = context.read<AuthCubit>();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('تسجيل الخروج'),
        content: const Text('هل تريد تسجيل الخروج؟ لن تصلك تنبيهات الطلبات بعد الخروج.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('خروج')),
        ],
      ),
    );
    if (ok == true) auth.signOut();
  }

  @override
  Widget build(BuildContext context) {
    final jobCount = context.select((JobsCubit c) => c.state.visible.length);
    final soundOn = context.select((JobsCubit c) => c.state.soundOn);
    final hasTrip = context.select((TripCubit c) => c.state.trip != null);

    return BlocListener<JobsCubit, JobsState>(
      listenWhen: (a, b) => a.alert?.id != b.alert?.id,
      listener: _onAlert,
      child: Scaffold(
        appBar: AppBar(
          title: Text(_tab == 0 ? 'الطلبات المتاحة' : 'رحلتي الحالية'),
          actions: [
            IconButton(
              tooltip: soundOn ? 'إيقاف التنبيه الصوتي' : 'تفعيل التنبيه الصوتي',
              icon: Icon(soundOn ? Icons.volume_up : Icons.volume_off),
              onPressed: () => context.read<JobsCubit>().toggleSound(),
            ),
            const ThemeToggleButton(),
            IconButton(tooltip: 'تسجيل الخروج', icon: const Icon(Icons.logout), onPressed: _logout),
          ],
        ),
        // IndexedStack يُبقي التبويبين حيّين، فلا يفوت سؤال «الرجعة» ولا يتوقف الجدار
        body: IndexedStack(index: _tab, children: [
          JobsScreen(driver: widget.user, onAccepted: () => _go(1)),
          TripScreen(onFindBackhaul: _findBackhaul),
        ]),
        bottomNavigationBar: NavigationBar(
          height: 76,
          selectedIndex: _tab,
          onDestinationSelected: _go,
          destinations: [
            NavigationDestination(
              icon: Badge(
                isLabelVisible: jobCount > 0,
                label: Text('$jobCount'),
                child: const Icon(Icons.list_alt_outlined),
              ),
              selectedIcon: const Icon(Icons.list_alt),
              label: 'الطلبات',
            ),
            NavigationDestination(
              icon: Badge(isLabelVisible: hasTrip, smallSize: 10, child: const Icon(Icons.local_shipping_outlined)),
              selectedIcon: const Icon(Icons.local_shipping),
              label: 'رحلتي',
            ),
          ],
        ),
      ),
    );
  }
}

/// نافذة «طلب جديد!» بأزرار كبيرة
class _NewJobDialog extends StatelessWidget {
  const _NewJobDialog({required this.job, required this.onView, required this.onIgnore});
  final Shipment job;
  final VoidCallback onView, onIgnore;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return AlertDialog(
      backgroundColor: cs.primaryContainer,
      icon: Icon(Icons.notifications_active, size: 56, color: cs.primary),
      title: const Text('طلب جديد!', textAlign: TextAlign.center, style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          Flexible(child: Text(job.fromName, style: _route)),
          const Padding(padding: EdgeInsets.symmetric(horizontal: 8), child: Icon(Icons.arrow_forward)),
          Flexible(child: Text(job.toName, style: _route)),
        ]),
        const SizedBox(height: 8),
        Text('${job.cargo.label} · ${job.distanceKm.round()} كم', style: const TextStyle(fontSize: 16)),
        const SizedBox(height: 12),
        Text(formatIqd(job.driverNet),
            style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w900, color: Colors.green)),
        const Text('صافي ربحك'),
      ]),
      actionsAlignment: MainAxisAlignment.center,
      actionsOverflowDirection: VerticalDirection.down,
      actions: [
        SizedBox(
          width: double.infinity,
          height: 64,
          child: FilledButton(onPressed: onView, child: const Text('عرض الطلب')),
        ),
        TextButton(onPressed: onIgnore, child: const Text('تجاهل وإيقاف الصوت', style: TextStyle(fontSize: 16))),
      ],
    );
  }

  static const _route = TextStyle(fontSize: 22, fontWeight: FontWeight.w800);
}
