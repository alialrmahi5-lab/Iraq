// إعداد مشروع أندرويد للتطبيقين تلقائياً (يعمل على ويندوز ولينكس وماك).
//
// الاستخدام من مجلد المشروع iraq_freight:
//     dart tool/setup_android.dart --maps-key=AIzaSy...
//
// ما يفعله لكل تطبيق (merchant_app و driver_app):
//   1) flutter create لتوليد مجلد android الأصلي (إن لم يوجد)
//   2) استبدال AndroidManifest.xml بنسخة android_config/ (الأذونات + مفتاح الخرائط)
//   3) رفع minSdk إلى 23 وإضافة مفتاح خرائط جوجل (تطبيق التاجر)
//   4) flutter pub get
import 'dart:io';

Future<void> main(List<String> args) async {
  final root = File.fromUri(Platform.script).parent.parent.path;
  final sep = Platform.pathSeparator;

  var mapsKey = Platform.environment['MAPS_API_KEY'] ?? '';
  for (final a in args) {
    if (a.startsWith('--maps-key=')) mapsKey = a.substring('--maps-key='.length);
  }
  if (mapsKey.isEmpty) {
    stdout.writeln('⚠️  لم يُمرَّر مفتاح خرائط جوجل (--maps-key=...). ستظهر الخريطة رمادية في تطبيق التاجر.');
    stdout.writeln('    يمكنك إضافته لاحقاً بسطر MAPS_API_KEY=... في merchant_app/android/gradle.properties\n');
  }

  stdout.writeln('▶ التحقق من Flutter...');
  if (await _run('flutter', ['--version'], root, quiet: true) != 0) {
    stderr.writeln('❌ أمر flutter غير موجود في PATH. ثبّت Flutter أولاً: https://docs.flutter.dev/get-started/install');
    exit(1);
  }

  for (final app in ['merchant_app', 'driver_app']) {
    final isMerchant = app == 'merchant_app';
    final dir = '$root$sep$app';
    stdout.writeln('\n════════ $app ════════');

    final hasAndroid = File('$dir${sep}android${sep}app${sep}build.gradle').existsSync() ||
        File('$dir${sep}android${sep}app${sep}build.gradle.kts').existsSync();
    if (!hasAndroid) {
      stdout.writeln('▶ توليد مجلد android...');
      final code = await _run(
        'flutter',
        ['create', '.', '--platforms=android', '--org', 'iq.freight', '--project-name', app],
        dir,
      );
      if (code != 0) {
        stderr.writeln('❌ فشل flutter create');
        exit(code);
      }
    } else {
      stdout.writeln('✓ مجلد android موجود');
    }

    // اختبار القالب الافتراضي يشير إلى MyApp غير الموجود
    final defaultTest = File('$dir${sep}test${sep}widget_test.dart');
    if (defaultTest.existsSync()) defaultTest.deleteSync();

    // الـ Manifest
    final src = File('$root${sep}android_config$sep${isMerchant ? 'merchant' : 'driver'}${sep}AndroidManifest.xml');
    final dst = File('$dir${sep}android${sep}app${sep}src${sep}main${sep}AndroidManifest.xml');
    dst.writeAsStringSync(src.readAsStringSync());
    stdout.writeln('✓ تم تطبيق AndroidManifest.xml (الأذونات)');

    // Gradle
    final kts = File('$dir${sep}android${sep}app${sep}build.gradle.kts');
    final groovy = File('$dir${sep}android${sep}app${sep}build.gradle');
    final gradle = kts.existsSync() ? kts : groovy;
    _patchGradle(gradle, maps: isMerchant);

    if (isMerchant && mapsKey.isNotEmpty) {
      final props = File('$dir${sep}android${sep}gradle.properties');
      final lines = props.existsSync() ? props.readAsLinesSync() : <String>[];
      lines.removeWhere((l) => l.startsWith('MAPS_API_KEY='));
      lines.add('MAPS_API_KEY=$mapsKey');
      props.writeAsStringSync('${lines.join('\n')}\n');
      stdout.writeln('✓ تم حفظ مفتاح الخرائط في android/gradle.properties');
    }

    stdout.writeln('▶ flutter pub get ...');
    final code = await _run('flutter', ['pub', 'get'], dir);
    if (code != 0) {
      stderr.writeln('❌ فشل flutter pub get في $app (تأكد من اتصال الإنترنت وإصدار Flutter)');
      exit(code);
    }
  }

  stdout.writeln('''

✅ اكتمل الإعداد. التشغيل التجريبي (بدون باكيند):
    cd merchant_app && flutter run        # رمز التحقق التجريبي: 123456
    cd driver_app   && flutter run

البناء النهائي (APK):
    flutter build apk --release \\
      --dart-define=SUPABASE_URL=https://xxxx.supabase.co \\
      --dart-define=SUPABASE_ANON_KEY=eyJ...
''');
}

void _patchGradle(File f, {required bool maps}) {
  final isKts = f.path.endsWith('.kts');
  var s = f.readAsStringSync();

  // minSdk 23: مطلوب لخرائط جوجل والموقع
  s = s.replaceAllMapped(RegExp(r'minSdk(Version)?\s*=?\s*flutter\.minSdkVersion'), (_) => 'minSdk = 23');
  stdout.writeln(s.contains('minSdk = 23')
      ? '✓ minSdk = 23'
      : '⚠️  لم أجد سطر minSdk في ${f.path}؛ تأكد يدوياً أنه 21 أو أعلى');

  if (maps && !s.contains('MAPS_API_KEY')) {
    final line = isKts
        ? '        manifestPlaceholders["MAPS_API_KEY"] = (project.findProperty("MAPS_API_KEY") as String?) ?: ""'
        : '        manifestPlaceholders = [MAPS_API_KEY: (project.findProperty("MAPS_API_KEY") ?: "")]';
    s = s.replaceFirstMapped(RegExp(r'defaultConfig\s*\{'), (m) => '${m[0]}\n$line');
    stdout.writeln('✓ تمت إضافة manifestPlaceholders لمفتاح الخرائط');
  }
  f.writeAsStringSync(s);
}

Future<int> _run(String exe, List<String> args, String cwd, {bool quiet = false}) async {
  final p = await Process.start(
    exe,
    args,
    workingDirectory: cwd,
    runInShell: true, // ضروري على ويندوز (flutter.bat)
    mode: quiet ? ProcessStartMode.normal : ProcessStartMode.inheritStdio,
  );
  if (quiet) {
    // نستهلك المخرجات حتى لا يتجمّد العملية
    p.stdout.drain<void>();
    p.stderr.drain<void>();
  }
  return p.exitCode;
}
