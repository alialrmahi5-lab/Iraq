# نظام شحن العراق: تطبيق التاجر + تطبيق السائق (Flutter + Supabase)

تطبيقان أندرويد مستقلان يتشاركان حزمة برمجية واحدة وباكيند سحابي واحد، واجهتهما عربية بالكامل (RTL).

```
iraq_freight/
├─ packages/freight_core/        ← الحزمة المشتركة
│   └─ lib/src/
│      ├─ models.dart             النماذج: الشحنة، المستخدم، الحالات
│      ├─ iraq_data.dart          المحافظات الـ 18 + المسافات
│      ├─ price_engine.dart       محرك التسعير الديناميكي
│      ├─ repository.dart         واجهة الباكيند (عقد واحد)
│      ├─ supabase_repository.dart   التنفيذ الحقيقي (Supabase)
│      ├─ mock_repository.dart       تنفيذ تجريبي بدون خادم
│      ├─ auth_cubit.dart / auth_widgets.dart   الدخول برقم الهاتف + OTP
│      └─ theme.dart              الوضع الليلي/النهاري
├─ merchant_app/                 ← تطبيق التاجر
│   └─ lib/ booking/ payment/ tracking/ + orders_screen + home_screen
├─ driver_app/                   ← تطبيق السائق
│   └─ lib/ jobs/ active/ register/ widgets/ + home_shell
├─ supabase/schema.sql           ← الجداول + الأمان (RLS) + الدوال
├─ android_config/               ← AndroidManifest لكل تطبيق (الأذونات)
└─ tool/setup_android.dart       ← يجهّز مجلدات أندرويد تلقائياً
```

المتطلبات: Flutter 3.27 أو أحدث (stable) وAndroid SDK.

## 1) التشغيل السريع بدون أي باكيند (الوضع التجريبي)

```bash
dart tool/setup_android.dart --maps-key=مفتاح_خرائط_جوجل
cd merchant_app && flutter run      # رمز OTP التجريبي: 123456
cd driver_app   && flutter run
```

بدون مفاتيح Supabase يعمل كل تطبيق ببيانات داخل الذاكرة:
- **التاجر**: بعد حجز شحنة يقبلها «سائق وهمي» بعد 8 ثوانٍ ثم يتحرك على الخريطة حتى التسليم.
- **السائق**: يصله طلب جديد كل 40 ثانية (لتجربة الصفارة)، ويُعتمد حسابه فوراً بعد رفع الوثائق.
- التطبيقان عمليتان منفصلتان، فلا يتشاركان البيانات في هذا الوضع.

مفتاح خرائط جوجل: Google Cloud Console ← تفعيل **Maps SDK for Android** ← إنشاء API key (قيّده باسم الحزمة `iq.freight.merchant_app`).

## 2) ربط Supabase (الوضع الحقيقي)

1. أنشئ مشروعاً في supabase.com ثم الصق `supabase/schema.sql` كاملاً في **SQL Editor** وشغّله.
2. **Authentication ← Providers ← Phone**: فعّله واختر مزوّد SMS (Twilio / MessageBird / Vonage).
   تحقق من أن المزوّد يغطي أرقام العراق (+964) وأسعاره. للتطوير استخدم «Test Phone Numbers» من نفس الصفحة.
3. انسخ `Project URL` و`anon key` من **Project Settings ← API**.
4. شغّل أو ابنِ مع المفتاحين:

```bash
flutter run --dart-define=SUPABASE_URL=https://xxxx.supabase.co --dart-define=SUPABASE_ANON_KEY=eyJ...
```

**اعتماد السائقين**: يرفع السائق وثائقه إلى مخزن `driver-docs`، وتراجعها الإدارة من لوحة Supabase، ثم:

```sql
update profiles set verification = 'approved' where id = '<uuid>';
```

(في آخر `schema.sql` استعلامات جاهزة لعرض الطلبات المعلّقة والرفض.)

## 3) بناء ملفات APK

```bash
cd merchant_app
flutter build apk --release --dart-define=SUPABASE_URL=... --dart-define=SUPABASE_ANON_KEY=...
# الناتج: build/app/outputs/flutter-apk/app-release.apk

cd ../driver_app
flutter build apk --release --dart-define=SUPABASE_URL=... --dart-define=SUPABASE_ANON_KEY=...
```

الـ APK يُوقَّع افتراضياً بمفتاح debug فيصلح للتجربة والتوزيع المباشر. للنشر على Google Play أنشئ keystore ووقّع به
(https://docs.flutter.dev/deployment/android#sign-the-app).

## 4) إدارة الحالة (BLoC / Cubit)

| الملف | وظيفته |
|---|---|
| `driver_app/lib/jobs/jobs_cubit.dart` | **جدار الطلبات**: تيار حي ← فلترة بنوع المركبة والنطاق ← تنبيه صوتي للطلب الجديد ← قبول ذرّي ← الرجعة الفارغة |
| `driver_app/lib/active/trip_cubit.dart` | الرحلة الجارية: GPS كل 30 ثانية، تحديث الحالة، إثبات التوصيل |
| `merchant_app/lib/tracking/tracking_cubit.dart` | **التتبع الحي**: يستقبل موقع السائق وحالة الشحنة كتيار |
| `merchant_app/lib/booking/booking_cubit.dart` | استمارة الحجز متعددة الخطوات والتسعير اللحظي |
| `merchant_app/lib/tracking/orders_cubit.dart` | سجل الطلبات (نشطة / مكتملة / ملغاة) |
| `packages/freight_core/lib/src/auth_cubit.dart` | مصادقة OTP مشتركة |

## 5) الأذونات المضافة

| الإذن | التطبيق | السبب |
|---|---|---|
| `INTERNET`, `ACCESS_NETWORK_STATE` | الاثنان | الباكيند والخرائط |
| `ACCESS_FINE/COARSE_LOCATION` | السائق | إرسال الموقع |
| `ACCESS_BACKGROUND_LOCATION` | السائق | التتبع مع التطبيق في الخلفية |
| `FOREGROUND_SERVICE`, `FOREGROUND_SERVICE_LOCATION`, `POST_NOTIFICATIONS`, `WAKE_LOCK` | السائق | خدمة أمامية بإشعار دائم (إلزامية في أندرويد 14) |
| `CAMERA` | السائق | صورة الوصل ووثائق السائق |

## 6) ما يجب إنجازه قبل الإطلاق الفعلي

هذه نسخة أولى جاهزة للتجربة، وليست جاهزة لاستقبال أموال حقيقية بعد:

1. **التسعير يُحسب في التطبيق** ثم يُرسَل للخادم. انقله إلى الخادم (Edge Function أو trigger) حتى لا يستطيع عميل معدَّل إرسال سعر مختلف. الأسعار الحالية في `price_engine.dart` قيم ابتدائية للتجربة.
2. **الدفع الإلكتروني محاكاة**: زين كاش وآسيا حوالة وكي كارد لا تتصل ببوابات فعلية، وكذلك `wallet_topup` في SQL تضيف رصيداً بلا دفع. استبدلها بـ Webhook من البوابة بصلاحية `service_role` وربط الدفع بالشحنة من الخادم.
3. **المسافات تقديرية** (خط مستقيم × 1.28 مع قيم معروفة لبعض المسارات). للدقة استخدم Google Distance Matrix من الخادم.
4. **التتبع في الخلفية** يعتمد على الخدمة الأمامية لمكتبة `location`: جرّبه على هاتف حقيقي، وتحقق من إعدادات توفير الطاقة لدى الشركات المصنّعة (شاومي/هواوي/سامسونغ) لأنها قد توقف الخدمة.
5. **الصوت بعد إغلاق التطبيق**: الصفارة تعمل والتطبيق مفتوح أو في الخلفية القريبة. للتنبيه وهو مغلق كلياً تحتاج إشعارات Push (FCM) إضافية.
6. أضف سياسة خصوصية وشروط استخدام، فالتطبيق يجمع الموقع ووثائق الهوية.
